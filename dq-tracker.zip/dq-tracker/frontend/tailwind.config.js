export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: { sans: ['"Public Sans"', 'system-ui', 'sans-serif'] },
      colors: {
        ink: { 900: '#0f2133', 800: '#16304a', 700: '#1f4262', 600: '#2d5a82' },
        brand: { 50: '#e8f4f8', 100: '#cde8f0', 500: '#1a85a8', 600: '#0f6e8c', 700: '#0b5873' },
        paper: '#f3f5f7',
      },
    },
  },
  plugins: [],
};
