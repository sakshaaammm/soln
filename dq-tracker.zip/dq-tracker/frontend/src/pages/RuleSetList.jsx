import { Fragment, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { deleteRuleSet, listRuleSets, setRuleSetStatus } from '../api';
import { errMsg } from '../api/client';
import RuleSummary from '../components/RuleSummary';
import { Empty, PageLoader, StatusBadge, fmtDate } from '../components/ui';
import { useToast } from '../context/ToastContext';

export default function RuleSetList() {
  const [rows, setRows] = useState(null);
  const [open, setOpen] = useState(null);
  const toast = useToast();
  const load = () => listRuleSets().then(setRows).catch((e) => { toast.error(errMsg(e)); setRows([]); });
  useEffect(() => { load(); }, []);

  const toggle = async (r) => {
    try { await setRuleSetStatus(r.id, !r.is_active); toast.success(`"${r.name}" ${r.is_active ? 'deactivated' : 'activated'}`); load(); }
    catch (e) { toast.error(errMsg(e)); }
  };
  const remove = async (r) => {
    if (!window.confirm(`Delete rule set "${r.name}"? Past uploads keep their results.`)) return;
    try { await deleteRuleSet(r.id); toast.success('Rule set deleted'); load(); } catch (e) { toast.error(errMsg(e)); }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="page-title">Rule sets</h1>
        <Link to="/admin/rulesets/new" className="btn-primary">New rule set</Link>
      </div>
      <div className="card overflow-x-auto">
        {!rows ? <PageLoader /> : !rows.length ? <Empty title="No rule sets yet">Create one to start validating files.</Empty> : (
          <table className="min-w-full divide-y divide-slate-200">
            <thead><tr><th className="th">Name</th><th className="th">Columns</th><th className="th">Updated</th><th className="th">Status</th><th className="th" /></tr></thead>
            <tbody className="divide-y divide-slate-100">
              {rows.map((r) => (
                <Fragment key={r.id}>
                  <tr>
                    <td className="td"><p className="font-medium text-ink-900">{r.name}</p><p className="max-w-md text-xs text-slate-500">{r.description}</p></td>
                    <td className="td">{r.config.columns?.length ?? 0}</td>
                    <td className="td whitespace-nowrap text-slate-600">{fmtDate(r.updated_at)}</td>
                    <td className="td"><StatusBadge status={r.is_active ? 'ACTIVE' : 'INACTIVE'} /></td>
                    <td className="td">
                      <div className="flex justify-end gap-2">
                        <button className="btn-secondary btn-sm" onClick={() => setOpen(open === r.id ? null : r.id)}>{open === r.id ? 'Hide rules' : 'View rules'}</button>
                        <Link className="btn-secondary btn-sm" to={`/admin/rulesets/${r.id}/edit`}>Edit</Link>
                        <button className="btn-secondary btn-sm" onClick={() => toggle(r)}>{r.is_active ? 'Deactivate' : 'Activate'}</button>
                        <button className="btn-danger btn-sm" onClick={() => remove(r)}>Delete</button>
                      </div>
                    </td>
                  </tr>
                  {open === r.id && <tr><td colSpan={5} className="bg-slate-50 px-5 py-4"><RuleSummary config={r.config} /></td></tr>}
                </Fragment>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
