import { useEffect, useState } from 'react';
import { listUploads } from '../api';
import { errMsg } from '../api/client';
import UploadsTable from '../components/UploadsTable';
import { PageLoader } from '../components/ui';
import { useToast } from '../context/ToastContext';

/** "All uploads" (admin) and "My uploads" (analyst): the backend scopes results by role. */
export default function UploadsList({ scope }) {
  const [rows, setRows] = useState(null);
  const [status, setStatus] = useState('');
  const [q, setQ] = useState('');
  const toast = useToast();
  const all = scope === 'all';

  useEffect(() => {
    setRows(null);
    listUploads(status ? { status } : {}).then(setRows).catch((e) => { toast.error(errMsg(e)); setRows([]); });
  }, [status]);

  const shown = (rows || []).filter((r) => {
    const t = q.trim().toLowerCase();
    return !t || [r.original_filename, r.ruleset_name, r.username].some((x) => x.toLowerCase().includes(t));
  });

  return (
    <div className="space-y-6">
      <h1 className="page-title">{all ? 'All uploads' : 'My uploads'}</h1>
      <div className="flex flex-wrap gap-3">
        <input className="input max-w-xs" placeholder="Search file, rule set or analyst" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search uploads" />
        <select className="input max-w-[10rem]" value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Filter by status">
          <option value="">All statuses</option>
          <option value="PASS">Pass</option>
          <option value="FLAGGED">Flagged</option>
        </select>
      </div>
      <div className="card">
        {rows === null ? <PageLoader /> : <UploadsTable uploads={shown} basePath={all ? '/admin/uploads' : '/analyst/uploads'} showUser={all} />}
      </div>
    </div>
  );
}
