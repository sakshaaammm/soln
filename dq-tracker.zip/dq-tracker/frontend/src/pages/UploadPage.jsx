import { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { createUpload, listRuleSets } from '../api';
import { errMsg } from '../api/client';
import FileDropzone from '../components/FileDropzone';
import RuleSummary from '../components/RuleSummary';
import { Empty, PageLoader, Spinner } from '../components/ui';
import { useToast } from '../context/ToastContext';

export default function UploadPage() {
  const [sets, setSets] = useState(null);
  const [rsId, setRsId] = useState('');
  const [file, setFile] = useState(null);
  const [progress, setProgress] = useState(null);
  const [validating, setValidating] = useState(false);
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const toast = useToast();

  useEffect(() => {
    listRuleSets().then((r) => { setSets(r); setRsId(params.get('ruleset') || (r[0] ? String(r[0].id) : '')); })
      .catch((e) => { toast.error(errMsg(e)); setSets([]); });
  }, []);

  if (!sets) return <PageLoader />;
  const selected = sets.find((s) => String(s.id) === String(rsId));
  const busy = progress !== null;

  const run = async () => {
    setProgress(0); setValidating(false);
    try {
      const res = await createUpload(file, rsId, (p) => { setProgress(p); if (p >= 100) setValidating(true); });
      toast.success(res.status === 'PASS' ? 'File passed all checks' : 'File was flagged. See the issues below.');
      navigate(`/analyst/uploads/${res.id}`);
    } catch (e) {
      toast.error(errMsg(e));
      setProgress(null); setValidating(false);
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="page-title">Validate a file</h1>
      {!sets.length ? <div className="card"><Empty title="No active rule sets">Ask an admin to activate one before uploading.</Empty></div> : (
        <>
          <div className="card space-y-4 p-5">
            <div className="max-w-md">
              <label className="label" htmlFor="rs">Rule set</label>
              <select id="rs" className="input" value={rsId} onChange={(e) => setRsId(e.target.value)} disabled={busy}>
                {sets.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </div>
            {selected && (
              <details>
                <summary className="cursor-pointer text-sm font-medium text-brand-600">What this rule set requires</summary>
                <div className="mt-3"><RuleSummary config={selected.config} /></div>
              </details>
            )}
          </div>
          <FileDropzone file={file} onFile={setFile} disabled={busy} />
          {busy && (
            <div aria-live="polite">
              <div className="h-2 overflow-hidden rounded-full bg-slate-200">
                <div className="h-full bg-brand-600 transition-all" style={{ width: `${progress}%` }} />
              </div>
              <p className="mt-2 flex items-center gap-2 text-sm text-slate-600">
                {validating ? <><Spinner className="h-4 w-4" /> Running checks…</> : `Uploading… ${progress}%`}
              </p>
            </div>
          )}
          <button className="btn-primary" disabled={!file || !rsId || busy} onClick={run}>Upload and validate</button>
        </>
      )}
    </div>
  );
}
