import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getStats, listRuleSets } from '../api';
import { errMsg } from '../api/client';
import RuleSummary from '../components/RuleSummary';
import UploadsTable from '../components/UploadsTable';
import { Empty, PageLoader, Stat } from '../components/ui';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

export default function AnalystDashboard() {
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  const [sets, setSets] = useState(null);
  const toast = useToast();
  useEffect(() => {
    getStats().then(setStats).catch((e) => toast.error(errMsg(e)));
    listRuleSets().then(setSets).catch((e) => { toast.error(errMsg(e)); setSets([]); });
  }, []);
  if (!stats || !sets) return <PageLoader />;

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="page-title">Welcome, {user.username}</h1>
        <Link to="/analyst/upload" className="btn-primary">Validate a file</Link>
      </div>
      <div className="grid gap-4 sm:grid-cols-3">
        <Stat label="My uploads" value={stats.total_uploads} />
        <Stat label="Passed" value={stats.passed} tone="text-emerald-700" />
        <Stat label="Flagged" value={stats.flagged} tone="text-red-700" />
      </div>

      <section className="space-y-3">
        <h2 className="font-semibold text-ink-900">Active rule sets</h2>
        {!sets.length ? <div className="card"><Empty title="No active rule sets">Ask an admin to activate one.</Empty></div> : sets.map((r) => (
          <details key={r.id} className="card group">
            <summary className="flex cursor-pointer list-none items-center justify-between gap-4 px-5 py-4">
              <div>
                <p className="font-semibold text-ink-900">{r.name}</p>
                <p className="text-sm text-slate-500">{r.description}</p>
              </div>
              <span className="shrink-0 text-sm font-medium text-brand-600 group-open:hidden">View rules</span>
              <span className="hidden shrink-0 text-sm font-medium text-brand-600 group-open:inline">Hide rules</span>
            </summary>
            <div className="space-y-4 border-t border-slate-200 px-5 py-4">
              <RuleSummary config={r.config} />
              <Link to={`/analyst/upload?ruleset=${r.id}`} className="btn-primary btn-sm">Validate a file against this</Link>
            </div>
          </details>
        ))}
      </section>

      <section className="card">
        <div className="flex items-center justify-between border-b border-slate-200 px-5 py-3">
          <h2 className="font-semibold text-ink-900">Recent uploads</h2>
          <Link to="/analyst/uploads" className="text-sm font-medium text-brand-600 hover:underline">See all</Link>
        </div>
        <UploadsTable uploads={stats.recent} basePath="/analyst/uploads" />
      </section>
    </div>
  );
}
