import { useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { downloadReport, getUpload } from '../api';
import { errMsg } from '../api/client';
import { Empty, PageLoader, Spinner, StatusBadge, fmtDate, fmtSize } from '../components/ui';
import { useToast } from '../context/ToastContext';

const PAGE = 100;

function Metric({ label, value }) {
  return (
    <div className="rounded-md bg-white/70 px-4 py-3">
      <p className="text-xs text-slate-600">{label}</p>
      <p className="text-xl font-bold text-ink-900">{value}</p>
    </div>
  );
}

export default function ResultPage({ backTo }) {
  const { id } = useParams();
  const [u, setU] = useState(null);
  const [error, setError] = useState('');
  const [dl, setDl] = useState(false);
  const [q, setQ] = useState('');
  const [limit, setLimit] = useState(PAGE);
  const toast = useToast();

  useEffect(() => { getUpload(id).then(setU).catch((e) => setError(errMsg(e))); }, [id]);

  const issues = useMemo(() => {
    const t = q.trim().toLowerCase();
    const all = u?.result?.issues || [];
    return t ? all.filter((i) => [i.column, i.rule, i.value, String(i.row)].some((x) => (x || '').toLowerCase().includes(t))) : all;
  }, [u, q]);

  if (error) return <div className="card"><Empty title="Could not load this result">{error} <Link to={backTo} className="text-brand-600 underline">Back to uploads</Link></Empty></div>;
  if (!u) return <PageLoader />;
  const r = u.result;
  const flagged = u.status === 'FLAGGED';

  const download = async () => {
    setDl(true);
    try { await downloadReport(u.id, `flagged_report_${u.original_filename.replace(/\.[^.]+$/, '')}.xlsx`); }
    catch (e) { toast.error('Could not download the report. It may no longer be available.'); }
    setDl(false);
  };

  return (
    <div className="space-y-6">
      <Link to={backTo} className="text-sm font-medium text-brand-600 hover:underline">Back to uploads</Link>

      <div className={`rounded-lg border p-6 ${flagged ? 'border-red-200 bg-red-50' : 'border-emerald-200 bg-emerald-50'}`}>
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-bold text-ink-900">{u.original_filename}</h1>
              <StatusBadge status={u.status} />
            </div>
            <p className="mt-1 text-sm text-slate-600">
              {u.ruleset_name} · {fmtSize(u.file_size)} · {fmtDate(u.created_at)} · uploaded by {u.username}
            </p>
            <p className={`mt-3 font-semibold ${flagged ? 'text-red-800' : 'text-emerald-800'}`}>
              {flagged ? `${r.issue_count} issue${r.issue_count === 1 ? '' : 's'} found. Fix them and upload the file again.` : 'All checks passed. Nothing to fix.'}
            </p>
          </div>
          {flagged && u.has_report && (
            <button className="btn-primary" onClick={download} disabled={dl}>{dl && <Spinner className="h-4 w-4" />} Download flagged report</button>
          )}
        </div>
        <div className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-5">
          <Metric label="Total rows" value={r.total_rows} />
          <Metric label="Total columns" value={r.total_columns} />
          <Metric label="Checks passed" value={r.checks_passed} />
          <Metric label="Checks failed" value={r.checks_failed} />
          <Metric label="Issues" value={r.issue_count} />
        </div>
      </div>

      {r.file_issues.length > 0 && (
        <section className="card">
          <h2 className="border-b border-slate-200 px-5 py-3 font-semibold text-ink-900">File-level issues</h2>
          <ul className="divide-y divide-slate-100">
            {r.file_issues.map((i, n) => (
              <li key={n} className="px-5 py-3 text-sm">
                <p className="font-medium text-red-800">{i.rule}{i.column ? `: ${i.column}` : ''}</p>
                <p className="text-slate-600">{i.expected}{i.value ? ` (found: ${i.value})` : ''}</p>
              </li>
            ))}
          </ul>
        </section>
      )}

      {r.issues.length > 0 && (
        <section className="card">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 px-5 py-3">
            <h2 className="font-semibold text-ink-900">Cell issues</h2>
            <input className="input max-w-xs" placeholder="Filter by column, rule or value" value={q} onChange={(e) => { setQ(e.target.value); setLimit(PAGE); }} aria-label="Filter issues" />
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200">
              <thead><tr><th className="th">Row</th><th className="th">Column</th><th className="th">Rule failed</th><th className="th">Actual value</th><th className="th">Expected</th></tr></thead>
              <tbody className="divide-y divide-slate-100">
                {issues.slice(0, limit).map((i, n) => (
                  <tr key={n}>
                    <td className="td font-medium">{i.row}</td>
                    <td className="td">{i.column}</td>
                    <td className="td">{i.rule}</td>
                    <td className="td font-mono text-xs text-red-700">{i.value === '' ? '(empty)' : i.value}</td>
                    <td className="td text-slate-600">{i.expected}</td>
                  </tr>
                ))}
                {!issues.length && <tr><td className="td text-slate-500" colSpan={5}>No issues match this filter.</td></tr>}
              </tbody>
            </table>
          </div>
          <div className="flex items-center justify-between px-5 py-3 text-sm text-slate-600">
            <span>Showing {Math.min(limit, issues.length)} of {issues.length}{r.issues_truncated ? ' (the report lists every issue)' : ''}</span>
            {limit < issues.length && <button className="btn-secondary btn-sm" onClick={() => setLimit(limit + PAGE)}>Show more</button>}
          </div>
        </section>
      )}

      <section className="card">
        <h2 className="border-b border-slate-200 px-5 py-3 font-semibold text-ink-900">Checks</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-200">
            <thead><tr><th className="th">Check</th><th className="th">Requirement</th><th className="th">Issues</th><th className="th">Result</th></tr></thead>
            <tbody className="divide-y divide-slate-100">
              {r.checks.map((c, n) => (
                <tr key={n}>
                  <td className="td font-medium text-ink-900">{c.name}</td>
                  <td className="td text-slate-600">{c.expected}</td>
                  <td className="td">{c.issues}</td>
                  <td className="td"><StatusBadge status={c.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
