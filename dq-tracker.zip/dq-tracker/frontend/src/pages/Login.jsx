import { useState } from 'react';
import { Navigate, useSearchParams } from 'react-router-dom';
import { errMsg } from '../api/client';
import { Spinner } from '../components/ui';
import { homeFor, useAuth } from '../context/AuthContext';

export default function Login() {
  const { user, loading, login } = useAuth();
  const [params] = useSearchParams();
  const [form, setForm] = useState({ username: '', password: '' });
  const [error, setError] = useState(params.get('expired') ? 'Your session has expired. Log in again to continue.' : '');
  const [busy, setBusy] = useState(false);

  if (!loading && user) return <Navigate to={homeFor(user.role)} replace />;

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      await login(form.username.trim(), form.password);
    } catch (err) {
      setError(errMsg(err, 'Login failed.'));
      setBusy(false);
    }
  };

  return (
    <div className="grid min-h-screen md:grid-cols-[1.1fr_1fr]">
      <section className="hidden flex-col justify-between bg-ink-900 p-12 text-slate-200 md:flex">
        <p className="text-lg font-bold text-white">Data Quality File Tracker</p>
        <div className="max-w-md">
          <h1 className="text-3xl font-bold leading-tight text-white">Know whether a file is clean before it moves downstream.</h1>
          <p className="mt-4 text-slate-400">Upload a spreadsheet, check it against your team's rules, and get a marked-up copy that shows exactly which cells to fix.</p>
          <div className="mt-8 grid grid-cols-[auto_1fr] gap-x-4 gap-y-3 text-sm">
            <span className="rounded-full bg-emerald-100 px-2.5 py-0.5 text-xs font-semibold text-emerald-800">PASS</span>
            <span>All checks met. Nothing to change.</span>
            <span className="rounded-full bg-red-100 px-2.5 py-0.5 text-xs font-semibold text-red-800">FLAGGED</span>
            <span>Issues found. Download the report, fix, re-upload.</span>
          </div>
        </div>
        <p className="text-sm text-slate-500">Sign in with the account your admin created for you.</p>
      </section>

      <section className="flex items-center justify-center bg-paper p-6">
        <form onSubmit={submit} className="card w-full max-w-sm space-y-5 p-8" noValidate>
          <div>
            <h2 className="text-xl font-bold text-ink-900">Log in</h2>
            <p className="mt-1 text-sm text-slate-500">Use your username or email.</p>
          </div>
          {error && <div role="alert" className="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-800">{error}</div>}
          <div>
            <label className="label" htmlFor="username">Username or email</label>
            <input id="username" className="input" autoComplete="username" autoFocus value={form.username}
              onChange={(e) => setForm({ ...form, username: e.target.value })} required />
          </div>
          <div>
            <label className="label" htmlFor="password">Password</label>
            <input id="password" type="password" className="input" autoComplete="current-password" value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })} required />
          </div>
          <button className="btn-primary w-full" disabled={busy || !form.username || !form.password}>
            {busy && <Spinner className="h-4 w-4" />} Log in
          </button>
        </form>
      </section>
    </div>
  );
}
