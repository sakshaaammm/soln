import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getStats } from '../api';
import { errMsg } from '../api/client';
import UploadsTable from '../components/UploadsTable';
import { PageLoader, Stat } from '../components/ui';
import { useToast } from '../context/ToastContext';

export default function AdminDashboard() {
  const [s, setS] = useState(null);
  const toast = useToast();
  useEffect(() => { getStats().then(setS).catch((e) => toast.error(errMsg(e))); }, []);
  if (!s) return <PageLoader />;
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="page-title">Admin dashboard</h1>
        <Link to="/admin/rulesets/new" className="btn-primary">New rule set</Link>
      </div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        <Stat label="Total uploads" value={s.total_uploads} />
        <Stat label="Passed" value={s.passed} tone="text-emerald-700" />
        <Stat label="Flagged" value={s.flagged} tone="text-red-700" />
        <Stat label="Analysts" value={s.analysts} />
        <Stat label="Active rule sets" value={s.active_rulesets} />
      </div>
      <section className="card">
        <div className="flex items-center justify-between border-b border-slate-200 px-5 py-3">
          <h2 className="font-semibold text-ink-900">Latest uploads</h2>
          <Link to="/admin/uploads" className="text-sm font-medium text-brand-600 hover:underline">See all</Link>
        </div>
        <UploadsTable uploads={s.recent} basePath="/admin/uploads" showUser />
      </section>
    </div>
  );
}
