import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { createRuleSet, getRuleSet, updateRuleSet } from '../api';
import { errMsg } from '../api/client';
import { PageLoader, Spinner } from '../components/ui';
import { useToast } from '../context/ToastContext';

const REGEX_PRESETS = {
  Email: '^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$',
  'Phone (10 digits)': '^\\d{10}$',
  'ID (ABC1234)': '^[A-Z]{3}\\d{4}$',
};
const DATE_FORMATS = ['%Y-%m-%d', '%d/%m/%Y', '%m/%d/%Y', '%Y-%m-%d %H:%M:%S'];
const uid = () => Math.random().toString(36).slice(2);

const newColumn = (name = '', mandatory = false) => ({
  key: uid(), name, mandatory, not_null: false, unique: false,
  type_on: false, data_type: 'string', date_format: '%Y-%m-%d',
  allowed_on: false, allowed_text: '', range_on: false, min_value: '', max_value: '',
  regex_on: false, regex: '', length_on: false, min_length: '', max_length: '',
});

const colToForm = (c, mandatory) => ({
  ...newColumn(c.name, mandatory),
  not_null: !!c.not_null, unique: !!c.unique,
  type_on: !!c.data_type, data_type: c.data_type || 'string', date_format: c.date_format || '%Y-%m-%d',
  allowed_on: !!c.allowed_values?.length, allowed_text: (c.allowed_values || []).join(', '),
  range_on: c.min_value != null || c.max_value != null, min_value: c.min_value ?? '', max_value: c.max_value ?? '',
  regex_on: !!c.regex, regex: c.regex || '',
  length_on: c.min_length != null || c.max_length != null, min_length: c.min_length ?? '', max_length: c.max_length ?? '',
});

const num = (v) => (v === '' || v == null ? null : Number(v));

const colToApi = (c) => ({
  name: c.name.trim(),
  not_null: c.not_null,
  unique: c.unique,
  data_type: c.type_on ? c.data_type : null,
  date_format: c.type_on && c.data_type === 'date' ? c.date_format : null,
  allowed_values: c.allowed_on ? c.allowed_text.split(',').map((s) => s.trim()).filter(Boolean) : null,
  min_value: c.range_on ? num(c.min_value) : null,
  max_value: c.range_on ? num(c.max_value) : null,
  regex: c.regex_on && c.regex ? c.regex : null,
  min_length: c.length_on ? num(c.min_length) : null,
  max_length: c.length_on ? num(c.max_length) : null,
});

const Check = ({ label, on, setOn, children }) => (
  <div className="rounded-md border border-slate-200 p-3">
    <label className="flex items-center gap-2 text-sm font-medium text-slate-700">
      <input type="checkbox" checked={on} onChange={(e) => setOn(e.target.checked)} className="h-4 w-4 rounded border-slate-300 text-brand-600" />
      {label}
    </label>
    {on && children && <div className="mt-3 flex flex-wrap items-center gap-2">{children}</div>}
  </div>
);

function ColumnEditor({ col, onChange, onRemove }) {
  const set = (patch) => onChange({ ...col, ...patch });
  const f = (k) => ({ value: col[k], onChange: (e) => set({ [k]: e.target.value }) });
  return (
    <div className="card space-y-4 p-4">
      <div className="flex flex-wrap items-end gap-3">
        <div className="min-w-[14rem] flex-1">
          <label className="label">Column name</label>
          <input className="input" placeholder="e.g. customer_id" {...f('name')} />
        </div>
        <label className="flex items-center gap-2 pb-2 text-sm font-medium text-slate-700">
          <input type="checkbox" checked={col.mandatory} onChange={(e) => set({ mandatory: e.target.checked })} className="h-4 w-4 rounded border-slate-300 text-brand-600" />
          Column must exist
        </label>
        <button type="button" className="btn-secondary btn-sm mb-1" onClick={onRemove}>Remove column</button>
      </div>
      <div className="grid gap-3 md:grid-cols-2">
        <Check label="Not null (no empty values)" on={col.not_null} setOn={(v) => set({ not_null: v })} />
        <Check label="Unique (no duplicates)" on={col.unique} setOn={(v) => set({ unique: v })} />
        <Check label="Data type" on={col.type_on} setOn={(v) => set({ type_on: v })}>
          <select className="input w-auto" {...f('data_type')}>
            {['string', 'integer', 'float', 'date', 'boolean'].map((t) => <option key={t}>{t}</option>)}
          </select>
          {col.data_type === 'date' && (
            <>
              <input className="input w-48" list="date-formats" aria-label="Date format" {...f('date_format')} />
              <datalist id="date-formats">{DATE_FORMATS.map((d) => <option key={d} value={d} />)}</datalist>
            </>
          )}
        </Check>
        <Check label="Allowed values" on={col.allowed_on} setOn={(v) => set({ allowed_on: v })}>
          <input className="input" placeholder="Active, Inactive, Pending (comma separated)" {...f('allowed_text')} />
        </Check>
        <Check label="Numeric range" on={col.range_on} setOn={(v) => set({ range_on: v })}>
          <input className="input w-28" type="number" step="any" placeholder="Min" {...f('min_value')} />
          <input className="input w-28" type="number" step="any" placeholder="Max" {...f('max_value')} />
        </Check>
        <Check label="String length" on={col.length_on} setOn={(v) => set({ length_on: v })}>
          <input className="input w-28" type="number" min="0" placeholder="Min" {...f('min_length')} />
          <input className="input w-28" type="number" min="0" placeholder="Max" {...f('max_length')} />
        </Check>
        <div className="md:col-span-2">
          <Check label="Regex pattern" on={col.regex_on} setOn={(v) => set({ regex_on: v })}>
            <select className="input w-auto" value="" onChange={(e) => e.target.value && set({ regex: REGEX_PRESETS[e.target.value] })} aria-label="Pattern preset">
              <option value="">Use a preset…</option>
              {Object.keys(REGEX_PRESETS).map((p) => <option key={p}>{p}</option>)}
            </select>
            <input className="input flex-1 font-mono" placeholder="^[A-Z]{3}\d{4}$" {...f('regex')} />
          </Check>
        </div>
      </div>
    </div>
  );
}

export default function RuleSetForm() {
  const { id } = useParams();
  const editing = !!id;
  const navigate = useNavigate();
  const toast = useToast();
  const [loading, setLoading] = useState(editing);
  const [busy, setBusy] = useState(false);
  const [meta, setMeta] = useState({ name: '', description: '', is_active: true });
  const [cfg, setCfg] = useState({
    column_matching: 'exact', disallow_extra_columns: false, min_rows: '', max_rows: '',
    types: { csv: true, xlsx: true, xls: true }, max_file_size_mb: 10,
  });
  const [columns, setColumns] = useState([newColumn()]);

  useEffect(() => {
    if (!editing) return;
    getRuleSet(id).then((rs) => {
      const c = rs.config;
      const mand = new Set(c.mandatory_columns || []);
      const cols = (c.columns || []).map((x) => colToForm(x, mand.has(x.name)));
      [...mand].filter((m) => !cols.some((x) => x.name === m)).forEach((m) => cols.push(colToForm({ name: m }, true)));
      setMeta({ name: rs.name, description: rs.description, is_active: rs.is_active });
      setCfg({
        column_matching: c.column_matching, disallow_extra_columns: c.disallow_extra_columns,
        min_rows: c.min_rows ?? '', max_rows: c.max_rows ?? '', max_file_size_mb: c.max_file_size_mb,
        types: { csv: c.allowed_file_types.includes('csv'), xlsx: c.allowed_file_types.includes('xlsx'), xls: c.allowed_file_types.includes('xls') },
      });
      setColumns(cols.length ? cols : [newColumn()]);
    }).catch((e) => { toast.error(errMsg(e)); navigate('/admin/rulesets'); }).finally(() => setLoading(false));
  }, [id]);

  const submit = async (e) => {
    e.preventDefault();
    const cols = columns.filter((c) => c.name.trim());
    const names = cols.map((c) => c.name.trim());
    if (new Set(names).size !== names.length) return toast.error('Column names must be unique within a rule set.');
    const body = {
      ...meta,
      config: {
        mandatory_columns: cols.filter((c) => c.mandatory).map((c) => c.name.trim()),
        column_matching: cfg.column_matching,
        disallow_extra_columns: cfg.disallow_extra_columns,
        min_rows: num(cfg.min_rows), max_rows: num(cfg.max_rows),
        allowed_file_types: Object.keys(cfg.types).filter((t) => cfg.types[t]),
        max_file_size_mb: Number(cfg.max_file_size_mb) || 10,
        columns: cols.map(colToApi),
      },
    };
    setBusy(true);
    try {
      editing ? await updateRuleSet(id, body) : await createRuleSet(body);
      toast.success(editing ? 'Rule set saved' : 'Rule set created');
      navigate('/admin/rulesets');
    } catch (err) { toast.error(errMsg(err)); setBusy(false); }
  };

  if (loading) return <PageLoader />;
  const updateCol = (key, next) => setColumns((cs) => cs.map((c) => (c.key === key ? next : c)));

  return (
    <form onSubmit={submit} className="space-y-8">
      <h1 className="page-title">{editing ? 'Edit rule set' : 'New rule set'}</h1>

      <section className="card space-y-4 p-5">
        <h2 className="font-semibold text-ink-900">Basics</h2>
        <div className="grid gap-4 md:grid-cols-2">
          <div><label className="label" htmlFor="rs-name">Name</label><input id="rs-name" className="input" value={meta.name} onChange={(e) => setMeta({ ...meta, name: e.target.value })} required minLength={2} /></div>
          <label className="flex items-center gap-2 self-end pb-2 text-sm font-medium text-slate-700">
            <input type="checkbox" checked={meta.is_active} onChange={(e) => setMeta({ ...meta, is_active: e.target.checked })} className="h-4 w-4 rounded border-slate-300 text-brand-600" />
            Active (analysts can use it)
          </label>
        </div>
        <div><label className="label" htmlFor="rs-desc">Description</label><textarea id="rs-desc" rows={2} className="input" value={meta.description} onChange={(e) => setMeta({ ...meta, description: e.target.value })} /></div>
      </section>

      <section className="card space-y-4 p-5">
        <h2 className="font-semibold text-ink-900">File rules</h2>
        <div className="grid gap-4 md:grid-cols-3">
          <div>
            <label className="label" htmlFor="rs-match">Column name matching</label>
            <select id="rs-match" className="input" value={cfg.column_matching} onChange={(e) => setCfg({ ...cfg, column_matching: e.target.value })}>
              <option value="exact">Exact</option>
              <option value="case_insensitive">Case-insensitive</option>
              <option value="ignore_spaces">Ignore extra spaces</option>
            </select>
          </div>
          <div><label className="label" htmlFor="rs-size">Max file size (MB)</label><input id="rs-size" type="number" min="0.1" step="any" className="input" value={cfg.max_file_size_mb} onChange={(e) => setCfg({ ...cfg, max_file_size_mb: e.target.value })} /></div>
          <div>
            <span className="label">Allowed file types</span>
            <div className="flex gap-4 pt-2 text-sm">
              {['csv', 'xlsx', 'xls'].map((t) => (
                <label key={t} className="flex items-center gap-1.5">
                  <input type="checkbox" checked={cfg.types[t]} onChange={(e) => setCfg({ ...cfg, types: { ...cfg.types, [t]: e.target.checked } })} className="h-4 w-4 rounded border-slate-300 text-brand-600" />.{t}
                </label>
              ))}
            </div>
          </div>
          <div><label className="label" htmlFor="rs-min">Minimum rows (optional)</label><input id="rs-min" type="number" min="0" className="input" value={cfg.min_rows} onChange={(e) => setCfg({ ...cfg, min_rows: e.target.value })} /></div>
          <div><label className="label" htmlFor="rs-max">Maximum rows (optional)</label><input id="rs-max" type="number" min="0" className="input" value={cfg.max_rows} onChange={(e) => setCfg({ ...cfg, max_rows: e.target.value })} /></div>
          <label className="flex items-center gap-2 self-end pb-2 text-sm font-medium text-slate-700">
            <input type="checkbox" checked={cfg.disallow_extra_columns} onChange={(e) => setCfg({ ...cfg, disallow_extra_columns: e.target.checked })} className="h-4 w-4 rounded border-slate-300 text-brand-600" />
            Disallow unexpected columns
          </label>
        </div>
      </section>

      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="font-semibold text-ink-900">Columns and checks</h2>
          <button type="button" className="btn-secondary" onClick={() => setColumns([...columns, newColumn()])}>Add column</button>
        </div>
        {columns.map((c) => (
          <ColumnEditor key={c.key} col={c} onChange={(n) => updateCol(c.key, n)} onRemove={() => setColumns(columns.filter((x) => x.key !== c.key))} />
        ))}
        {!columns.length && <p className="text-sm text-slate-500">No columns yet. Add one to define its checks.</p>}
      </section>

      <div className="flex gap-3">
        <button className="btn-primary" disabled={busy}>{busy && <Spinner className="h-4 w-4" />} Save rule set</button>
        <button type="button" className="btn-secondary" onClick={() => navigate('/admin/rulesets')}>Cancel</button>
      </div>
    </form>
  );
}
