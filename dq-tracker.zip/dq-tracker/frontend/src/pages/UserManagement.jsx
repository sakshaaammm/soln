import { useEffect, useState } from 'react';
import { createUser, listUsers, updateUser } from '../api';
import { errMsg } from '../api/client';
import { Empty, PageLoader, Spinner, StatusBadge, fmtDate } from '../components/ui';
import { useToast } from '../context/ToastContext';

const blank = { username: '', email: '', password: '' };

export default function UserManagement() {
  const [users, setUsers] = useState(null);
  const [form, setForm] = useState(blank);
  const [busy, setBusy] = useState(false);
  const toast = useToast();
  const load = () => listUsers().then(setUsers).catch((e) => toast.error(errMsg(e)));
  useEffect(() => { load(); }, []);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      await createUser(form);
      toast.success(`Analyst "${form.username}" created`);
      setForm(blank);
      load();
    } catch (err) { toast.error(errMsg(err)); }
    setBusy(false);
  };
  const toggle = async (u) => {
    try {
      await updateUser(u.id, { is_active: !u.is_active });
      toast.success(`${u.username} ${u.is_active ? 'deactivated' : 'activated'}`);
      load();
    } catch (err) { toast.error(errMsg(err)); }
  };
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  return (
    <div className="space-y-8">
      <h1 className="page-title">Analysts</h1>
      <form onSubmit={submit} className="card grid gap-4 p-5 md:grid-cols-4 md:items-end">
        <div><label className="label" htmlFor="u-name">Username</label><input id="u-name" className="input" value={form.username} onChange={set('username')} required minLength={3} /></div>
        <div><label className="label" htmlFor="u-email">Email</label><input id="u-email" type="email" className="input" value={form.email} onChange={set('email')} required /></div>
        <div><label className="label" htmlFor="u-pass">Password (8+ characters)</label><input id="u-pass" type="password" className="input" value={form.password} onChange={set('password')} required minLength={8} autoComplete="new-password" /></div>
        <button className="btn-primary" disabled={busy}>{busy && <Spinner className="h-4 w-4" />} Create analyst</button>
      </form>
      <div className="card overflow-x-auto">
        {!users ? <PageLoader /> : !users.length ? <Empty title="No users" /> : (
          <table className="min-w-full divide-y divide-slate-200">
            <thead><tr><th className="th">Username</th><th className="th">Email</th><th className="th">Role</th><th className="th">Created</th><th className="th">Status</th><th className="th" /></tr></thead>
            <tbody className="divide-y divide-slate-100">
              {users.map((u) => (
                <tr key={u.id}>
                  <td className="td font-medium text-ink-900">{u.username}</td>
                  <td className="td">{u.email}</td>
                  <td className="td">{u.role === 'ADMIN' ? 'Admin' : 'Data analyst'}</td>
                  <td className="td text-slate-600">{fmtDate(u.created_at)}</td>
                  <td className="td"><StatusBadge status={u.is_active ? 'ACTIVE' : 'INACTIVE'} /></td>
                  <td className="td text-right">
                    {u.role !== 'ADMIN' && <button className="btn-secondary btn-sm" onClick={() => toggle(u)}>{u.is_active ? 'Deactivate' : 'Activate'}</button>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
