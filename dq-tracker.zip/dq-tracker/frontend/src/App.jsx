import { Navigate, Route, Routes } from 'react-router-dom';
import Layout from './components/Layout';
import ProtectedRoute from './components/ProtectedRoute';
import { homeFor, useAuth } from './context/AuthContext';
import Login from './pages/Login';
import AdminDashboard from './pages/AdminDashboard';
import RuleSetList from './pages/RuleSetList';
import RuleSetForm from './pages/RuleSetForm';
import UserManagement from './pages/UserManagement';
import UploadsList from './pages/UploadsList';
import AnalystDashboard from './pages/AnalystDashboard';
import UploadPage from './pages/UploadPage';
import ResultPage from './pages/ResultPage';

function Home() {
  const { user, loading } = useAuth();
  if (loading) return null;
  return <Navigate to={user ? homeFor(user.role) : '/login'} replace />;
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login />} />

      <Route element={<ProtectedRoute roles={['ADMIN']} />}>
        <Route element={<Layout />}>
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="/admin/rulesets" element={<RuleSetList />} />
          <Route path="/admin/rulesets/new" element={<RuleSetForm />} />
          <Route path="/admin/rulesets/:id/edit" element={<RuleSetForm />} />
          <Route path="/admin/users" element={<UserManagement />} />
          <Route path="/admin/uploads" element={<UploadsList scope="all" />} />
          <Route path="/admin/uploads/:id" element={<ResultPage backTo="/admin/uploads" />} />
        </Route>
      </Route>

      <Route element={<ProtectedRoute roles={['DATA_ANALYST']} />}>
        <Route element={<Layout />}>
          <Route path="/analyst" element={<AnalystDashboard />} />
          <Route path="/analyst/upload" element={<UploadPage />} />
          <Route path="/analyst/uploads" element={<UploadsList scope="mine" />} />
          <Route path="/analyst/uploads/:id" element={<ResultPage backTo="/analyst/uploads" />} />
        </Route>
      </Route>

      <Route path="*" element={<Home />} />
    </Routes>
  );
}
