const MATCH = { exact: 'Exact match', case_insensitive: 'Case-insensitive', ignore_spaces: 'Ignore extra spaces' };

function colRules(c) {
  const r = [];
  if (c.not_null) r.push('Required (not empty)');
  if (c.unique) r.push('Unique');
  if (c.data_type) r.push(c.data_type === 'date' ? `Date (${c.date_format})` : `Type: ${c.data_type}`);
  if (c.allowed_values?.length) r.push(`One of: ${c.allowed_values.join(', ')}`);
  if (c.min_value != null || c.max_value != null) r.push(`Range: ${c.min_value ?? '−∞'} to ${c.max_value ?? '∞'}`);
  if (c.regex) r.push(`Pattern: ${c.regex}`);
  if (c.min_length != null || c.max_length != null) r.push(`Length: ${c.min_length ?? 0} to ${c.max_length ?? '∞'}`);
  return r;
}

/** Read-only description of what a rule set requires. */
export default function RuleSummary({ config }) {
  const c = config || {};
  const general = [
    `File types: ${(c.allowed_file_types || []).map((t) => '.' + t).join(', ')}`,
    `Max file size: ${c.max_file_size_mb} MB`,
    `Column names: ${MATCH[c.column_matching] || 'Exact match'}`,
    c.disallow_extra_columns && 'No unexpected columns allowed',
    c.min_rows != null && `Minimum rows: ${c.min_rows}`,
    c.max_rows != null && `Maximum rows: ${c.max_rows}`,
  ].filter(Boolean);
  const mandatory = new Set(c.mandatory_columns || []);
  const names = [...(c.columns || []).map((x) => x.name), ...[...mandatory].filter((m) => !(c.columns || []).some((x) => x.name === m))];

  return (
    <div className="space-y-4 text-sm">
      <ul className="list-inside list-disc text-slate-600">{general.map((g) => <li key={g}>{g}</li>)}</ul>
      <div className="overflow-x-auto rounded-md border border-slate-200">
        <table className="min-w-full divide-y divide-slate-200">
          <thead><tr><th className="th">Column</th><th className="th">Mandatory</th><th className="th">Requirements</th></tr></thead>
          <tbody className="divide-y divide-slate-100">
            {names.map((n) => {
              const col = (c.columns || []).find((x) => x.name === n) || {};
              const rules = colRules(col);
              return (
                <tr key={n}>
                  <td className="td font-medium text-ink-900">{n}</td>
                  <td className="td">{mandatory.has(n) ? 'Yes' : 'No'}</td>
                  <td className="td text-slate-600">{rules.length ? rules.join(' · ') : 'No value rules'}</td>
                </tr>
              );
            })}
            {!names.length && <tr><td className="td text-slate-500" colSpan={3}>No column rules defined.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
