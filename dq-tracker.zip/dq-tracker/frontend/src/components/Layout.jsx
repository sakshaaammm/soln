import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const NAV = {
  ADMIN: [
    { to: '/admin', label: 'Dashboard', end: true },
    { to: '/admin/rulesets', label: 'Rule sets' },
    { to: '/admin/uploads', label: 'All uploads' },
    { to: '/admin/users', label: 'Analysts' },
  ],
  DATA_ANALYST: [
    { to: '/analyst', label: 'Dashboard', end: true },
    { to: '/analyst/upload', label: 'Validate a file' },
    { to: '/analyst/uploads', label: 'My uploads' },
  ],
};

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const doLogout = () => {
    logout();
    navigate('/login');
  };
  return (
    <div className="flex min-h-screen flex-col md:flex-row">
      <aside className="bg-ink-900 text-slate-300 md:w-60 md:shrink-0">
        <div className="flex items-center justify-between px-5 py-5 md:block">
          <div>
            <p className="text-base font-bold text-white">Data Quality</p>
            <p className="text-sm text-slate-400">File Tracker</p>
          </div>
        </div>
        <nav className="flex gap-1 overflow-x-auto px-3 pb-3 md:flex-col md:pb-0" aria-label="Main">
          {NAV[user.role].map((n) => (
            <NavLink
              key={n.to}
              to={n.to}
              end={n.end}
              className={({ isActive }) =>
                `whitespace-nowrap rounded-md px-3 py-2 text-sm font-medium transition ${
                  isActive ? 'bg-ink-700 text-white' : 'hover:bg-ink-800 hover:text-white'
                }`
              }
            >
              {n.label}
            </NavLink>
          ))}
        </nav>
      </aside>
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center justify-end gap-4 border-b border-slate-200 bg-white px-6 py-3">
          <div className="text-right text-sm">
            <p className="font-semibold text-ink-900">{user.username}</p>
            <p className="text-xs text-slate-500">{user.role === 'ADMIN' ? 'Admin' : 'Data analyst'}</p>
          </div>
          <button className="btn-secondary btn-sm" onClick={doLogout}>Log out</button>
        </header>
        <main className="mx-auto w-full max-w-6xl flex-1 px-6 py-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
