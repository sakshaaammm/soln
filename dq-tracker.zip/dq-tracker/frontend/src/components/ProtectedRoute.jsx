import { Navigate, Outlet } from 'react-router-dom';
import { homeFor, useAuth } from '../context/AuthContext';
import { PageLoader } from './ui';

export default function ProtectedRoute({ roles }) {
  const { user, loading } = useAuth();
  if (loading) return <PageLoader />;
  if (!user) return <Navigate to="/login" replace />;
  if (!roles.includes(user.role)) return <Navigate to={homeFor(user.role)} replace />;
  return <Outlet />;
}
