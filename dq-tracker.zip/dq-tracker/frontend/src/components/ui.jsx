export function Spinner({ className = 'h-5 w-5' }) {
  return <span className={`inline-block animate-spin rounded-full border-2 border-slate-300 border-t-brand-600 ${className}`} aria-hidden />;
}

export function PageLoader({ label = 'Loading…' }) {
  return (
    <div className="flex items-center justify-center gap-3 py-20 text-sm text-slate-500">
      <Spinner /> {label}
    </div>
  );
}

const BADGE = {
  PASS: 'bg-emerald-100 text-emerald-800 ring-emerald-200',
  FAIL: 'bg-red-100 text-red-800 ring-red-200',
  FLAGGED: 'bg-red-100 text-red-800 ring-red-200',
  SKIPPED: 'bg-slate-100 text-slate-600 ring-slate-200',
  ACTIVE: 'bg-emerald-100 text-emerald-800 ring-emerald-200',
  INACTIVE: 'bg-slate-100 text-slate-600 ring-slate-200',
};
export function StatusBadge({ status }) {
  return (
    <span className={`inline-block rounded-full px-2.5 py-0.5 text-xs font-semibold ring-1 ring-inset ${BADGE[status] || BADGE.SKIPPED}`}>
      {status === 'ACTIVE' ? 'Active' : status === 'INACTIVE' ? 'Inactive' : status}
    </span>
  );
}

export function Empty({ title, children }) {
  return (
    <div className="px-6 py-14 text-center">
      <p className="font-semibold text-slate-700">{title}</p>
      {children && <div className="mt-1 text-sm text-slate-500">{children}</div>}
    </div>
  );
}

export function Stat({ label, value, tone = 'text-ink-900' }) {
  return (
    <div className="card p-5">
      <p className="text-sm text-slate-500">{label}</p>
      <p className={`mt-1 text-3xl font-bold ${tone}`}>{value ?? '–'}</p>
    </div>
  );
}

export const fmtDate = (d) => new Date(d).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
export const fmtSize = (b) => (b < 1024 ? `${b} B` : b < 1048576 ? `${(b / 1024).toFixed(1)} KB` : `${(b / 1048576).toFixed(1)} MB`);
