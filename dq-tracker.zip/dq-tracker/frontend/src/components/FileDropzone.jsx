import { useRef, useState } from 'react';
import { fmtSize } from './ui';

export default function FileDropzone({ file, onFile, disabled, accept = '.csv,.xlsx,.xls' }) {
  const input = useRef(null);
  const [over, setOver] = useState(false);
  const pick = (f) => f && onFile(f);

  return (
    <div
      onDragOver={(e) => { e.preventDefault(); if (!disabled) setOver(true); }}
      onDragLeave={() => setOver(false)}
      onDrop={(e) => { e.preventDefault(); setOver(false); if (!disabled) pick(e.dataTransfer.files?.[0]); }}
      onClick={() => !disabled && input.current?.click()}
      onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && !disabled && input.current?.click()}
      role="button"
      tabIndex={0}
      className={`cursor-pointer rounded-lg border-2 border-dashed px-6 py-10 text-center transition ${
        over ? 'border-brand-500 bg-brand-50' : 'border-slate-300 bg-white hover:border-brand-500'
      } ${disabled ? 'cursor-not-allowed opacity-60' : ''}`}
    >
      <input ref={input} type="file" accept={accept} hidden onChange={(e) => pick(e.target.files?.[0])} />
      {file ? (
        <>
          <p className="font-semibold text-ink-900">{file.name}</p>
          <p className="mt-1 text-sm text-slate-500">{fmtSize(file.size)} · click or drop to replace</p>
        </>
      ) : (
        <>
          <p className="font-semibold text-ink-900">Drop a file here, or click to browse</p>
          <p className="mt-1 text-sm text-slate-500">CSV, XLSX or XLS</p>
        </>
      )}
    </div>
  );
}
