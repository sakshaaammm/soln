import { Link } from 'react-router-dom';
import { Empty, StatusBadge, fmtDate } from './ui';

export default function UploadsTable({ uploads, basePath, showUser }) {
  if (!uploads.length) return <Empty title="No uploads yet">Validated files will appear here.</Empty>;
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-slate-200">
        <thead>
          <tr>
            <th className="th">File</th>
            {showUser && <th className="th">Analyst</th>}
            <th className="th">Rule set</th>
            <th className="th">Date</th>
            <th className="th">Issues</th>
            <th className="th">Status</th>
            <th className="th" />
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {uploads.map((u) => (
            <tr key={u.id} className="hover:bg-slate-50">
              <td className="td font-medium text-ink-900">{u.original_filename}</td>
              {showUser && <td className="td">{u.username}</td>}
              <td className="td">{u.ruleset_name}</td>
              <td className="td whitespace-nowrap text-slate-600">{fmtDate(u.created_at)}</td>
              <td className="td">{u.issue_count}</td>
              <td className="td"><StatusBadge status={u.status} /></td>
              <td className="td text-right">
                <Link className="btn-secondary btn-sm" to={`${basePath}/${u.id}`}>View result</Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
