import api from './client';

export const login = (username, password) => api.post('/auth/login', { username, password }).then((r) => r.data);
export const getMe = () => api.get('/auth/me').then((r) => r.data);

export const listUsers = () => api.get('/users').then((r) => r.data);
export const createUser = (body) => api.post('/users', body).then((r) => r.data);
export const updateUser = (id, body) => api.patch(`/users/${id}`, body).then((r) => r.data);

export const listRuleSets = () => api.get('/rulesets').then((r) => r.data);
export const getRuleSet = (id) => api.get(`/rulesets/${id}`).then((r) => r.data);
export const createRuleSet = (body) => api.post('/rulesets', body).then((r) => r.data);
export const updateRuleSet = (id, body) => api.put(`/rulesets/${id}`, body).then((r) => r.data);
export const setRuleSetStatus = (id, is_active) => api.patch(`/rulesets/${id}/status`, { is_active }).then((r) => r.data);
export const deleteRuleSet = (id) => api.delete(`/rulesets/${id}`);

export const getStats = () => api.get('/uploads/stats').then((r) => r.data);
export const listUploads = (params) => api.get('/uploads', { params }).then((r) => r.data);
export const getUpload = (id) => api.get(`/uploads/${id}`).then((r) => r.data);
export const createUpload = (file, rulesetId, onProgress) => {
  const fd = new FormData();
  fd.append('file', file);
  fd.append('ruleset_id', rulesetId);
  return api
    .post('/uploads', fd, {
      onUploadProgress: (e) => e.total && onProgress?.(Math.round((e.loaded * 100) / e.total)),
    })
    .then((r) => r.data);
};
export async function downloadReport(id, filename) {
  const res = await api.get(`/uploads/${id}/download`, { responseType: 'blob' });
  const url = URL.createObjectURL(res.data);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename || `flagged_report_${id}.xlsx`;
  a.click();
  URL.revokeObjectURL(url);
}
