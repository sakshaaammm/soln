import re
from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator, model_validator

DataType = Literal["integer", "float", "string", "date", "boolean"]


# ---------- Auth / users ----------
class LoginRequest(BaseModel):
    username: str = Field(min_length=1, description="Username or email")
    password: str = Field(min_length=1)


class UserCreate(BaseModel):
    username: str = Field(min_length=3, max_length=64, pattern=r"^[A-Za-z0-9_.-]+$")
    email: EmailStr
    password: str = Field(min_length=8, max_length=72)


class UserUpdate(BaseModel):
    is_active: bool | None = None
    password: str | None = Field(default=None, min_length=8, max_length=72)


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    username: str
    email: str
    role: str
    is_active: bool
    created_at: datetime


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


# ---------- Rule sets ----------
class ColumnRule(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    data_type: DataType | None = None
    date_format: str | None = None  # strptime format, e.g. %Y-%m-%d
    not_null: bool = False
    unique: bool = False
    allowed_values: list[str] | None = None
    min_value: float | None = None
    max_value: float | None = None
    regex: str | None = None
    min_length: int | None = Field(default=None, ge=0)
    max_length: int | None = Field(default=None, ge=0)

    @field_validator("regex")
    @classmethod
    def _regex_ok(cls, v):
        if v:
            try:
                re.compile(v)
            except re.error as e:
                raise ValueError(f"Invalid regular expression: {e}")
        return v or None

    @model_validator(mode="after")
    def _consistency(self):
        if self.data_type == "date" and not self.date_format:
            self.date_format = "%Y-%m-%d"
        if self.min_value is not None and self.max_value is not None and self.min_value > self.max_value:
            raise ValueError(f"Column '{self.name}': min value cannot exceed max value")
        if self.min_length is not None and self.max_length is not None and self.min_length > self.max_length:
            raise ValueError(f"Column '{self.name}': min length cannot exceed max length")
        if self.allowed_values is not None and len(self.allowed_values) == 0:
            self.allowed_values = None
        return self


class RuleConfig(BaseModel):
    mandatory_columns: list[str] = []
    column_matching: Literal["exact", "case_insensitive", "ignore_spaces"] = "exact"
    disallow_extra_columns: bool = False
    min_rows: int | None = Field(default=None, ge=0)
    max_rows: int | None = Field(default=None, ge=0)
    allowed_file_types: list[Literal["csv", "xlsx", "xls"]] = ["csv", "xlsx", "xls"]
    max_file_size_mb: float = Field(default=10, gt=0, le=500)
    columns: list[ColumnRule] = []

    @model_validator(mode="after")
    def _consistency(self):
        if self.min_rows is not None and self.max_rows is not None and self.min_rows > self.max_rows:
            raise ValueError("Minimum row count cannot exceed maximum row count")
        if not self.allowed_file_types:
            raise ValueError("Select at least one allowed file type")
        names = [c.name for c in self.columns]
        if len(names) != len(set(names)):
            raise ValueError("Duplicate column names in rule set")
        return self


class RuleSetCreate(BaseModel):
    name: str = Field(min_length=2, max_length=150)
    description: str = ""
    is_active: bool = True
    config: RuleConfig


class RuleSetUpdate(RuleSetCreate):
    pass


class RuleSetStatus(BaseModel):
    is_active: bool


class RuleSetOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    description: str
    is_active: bool
    config: dict[str, Any]
    created_at: datetime
    updated_at: datetime


# ---------- Uploads / results ----------
class UploadOut(BaseModel):
    id: int
    original_filename: str
    ruleset_id: int | None
    ruleset_name: str
    status: str
    file_size: int
    created_at: datetime
    user_id: int
    username: str
    issue_count: int
    has_report: bool


class ResultOut(BaseModel):
    total_rows: int
    total_columns: int
    checks_passed: int
    checks_failed: int
    issue_count: int
    issues_truncated: bool
    file_issues: list[dict[str, Any]]
    issues: list[dict[str, Any]]
    checks: list[dict[str, Any]]


class UploadDetail(UploadOut):
    result: ResultOut | None


class StatsOut(BaseModel):
    total_uploads: int
    passed: int
    flagged: int
    analysts: int | None = None
    active_rulesets: int | None = None
    recent: list[UploadOut]
