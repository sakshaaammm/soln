"""Builds the downloadable 'Flagged Report' workbook."""
from collections import defaultdict
from pathlib import Path

import pandas as pd
from openpyxl import Workbook
from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE
from openpyxl.comments import Comment
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from .engine import ValidationOutcome

RED = PatternFill("solid", start_color="FFC7CE", end_color="FFC7CE")
GREEN = PatternFill("solid", start_color="C6EFCE", end_color="C6EFCE")
GREY = PatternFill("solid", start_color="D9E2EC", end_color="D9E2EC")
BOLD = Font(bold=True)


def _put(ws, row, col, value):
    """Write a value as plain text (prevents formulas from executing, strips illegal characters)."""
    cell = ws.cell(row=row, column=col)
    text = ILLEGAL_CHARACTERS_RE.sub("", "" if value is None else str(value))
    cell.value = text
    cell.data_type = "s"
    return cell


def _header(ws, headers):
    for i, h in enumerate(headers, 1):
        c = _put(ws, 1, i, h)
        c.font, c.fill = BOLD, GREY
    ws.freeze_panes = "A2"


def _autosize(ws, max_width=60):
    for col in ws.columns:
        longest = max((len(str(c.value)) for c in col if c.value is not None), default=8)
        ws.column_dimensions[get_column_letter(col[0].column)].width = min(max(longest + 2, 10), max_width)


def build_flagged_report(df: pd.DataFrame, outcome: ValidationOutcome, out_path: Path) -> None:
    wb = Workbook()

    # ---- Sheet 1: Data (rows stay at their original spreadsheet row numbers)
    ws = wb.active
    ws.title = "Data"
    cols = list(df.columns)
    _header(ws, cols + ["Issues"])
    by_cell: dict[tuple[int, str], list[str]] = defaultdict(list)
    by_row: dict[int, list[str]] = defaultdict(list)
    for iss in outcome.issues:
        msg = f"[{iss.rule}] {iss.expected}"
        by_cell[(iss.row, iss.column)].append(msg)
        by_row[iss.row].append(f"{iss.column}: {iss.rule}")
    col_idx = {c: i for i, c in enumerate(cols, 1)}
    for idx, row in df.iterrows():
        r = int(idx) + 2
        for c in cols:
            _put(ws, r, col_idx[c], row[c])
        if r in by_row:
            _put(ws, r, len(cols) + 1, "; ".join(by_row[r])).font = Font(color="9C0006")
    for (r, c), msgs in by_cell.items():
        cell = ws.cell(row=r, column=col_idx[c])
        cell.fill = RED
        comment = Comment("\n".join(msgs), "Data Quality Tracker")
        comment.width, comment.height = 320, 40 + 30 * len(msgs)
        cell.comment = comment
    for iss in outcome.file_issues:  # flag header cells for column-level file issues (e.g. unexpected column)
        if iss.column in col_idx and iss.value == "(unexpected column)":
            h = ws.cell(row=1, column=col_idx[iss.column])
            h.fill = RED
            h.comment = Comment(f"[{iss.rule}] {iss.expected}", "Data Quality Tracker")
    _autosize(ws)

    # ---- Sheet 2: Issue Summary
    s2 = wb.create_sheet("Issue Summary")
    _header(s2, ["Row", "Column", "Rule", "Value", "Expected"])
    r = 2
    for iss in outcome.file_issues + outcome.issues:
        for c, v in enumerate([iss.row if iss.row is not None else "(file)", iss.column or "", iss.rule, iss.value or "", iss.expected], 1):
            _put(s2, r, c, v)
        r += 1
    _autosize(s2)

    # ---- Sheet 3: Checks
    s3 = wb.create_sheet("Checks")
    _header(s3, ["Check", "Scope", "Column", "Expected", "Status", "Issues"])
    for r, chk in enumerate(outcome.checks, 2):
        for c, v in enumerate([chk["name"], chk["scope"], chk["column"] or "", chk["expected"], chk["status"], chk["issues"]], 1):
            _put(s3, r, c, v)
        s3.cell(row=r, column=5).fill = RED if chk["status"] == "FAIL" else GREEN if chk["status"] == "PASS" else GREY
    _autosize(s3)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(out_path)
