"""Validation engine: orchestrates file-level and column-level checks and produces a ValidationOutcome."""
from dataclasses import dataclass, field

import pandas as pd

from .checks import COLUMN_CHECKS, FILE_CHECKS, Context, Issue, normalize

MAX_STORED_ISSUES = 5000  # cap persisted in DB; the Excel report always contains every issue


@dataclass
class ValidationOutcome:
    status: str
    total_rows: int
    total_columns: int
    checks: list[dict] = field(default_factory=list)
    issues: list[Issue] = field(default_factory=list)  # cell-level
    file_issues: list[Issue] = field(default_factory=list)

    @property
    def checks_passed(self) -> int:
        return sum(1 for c in self.checks if c["status"] == "PASS")

    @property
    def checks_failed(self) -> int:
        return sum(1 for c in self.checks if c["status"] == "FAIL")

    @property
    def issue_count(self) -> int:
        return len(self.issues) + len(self.file_issues)


def _resolve_columns(df: pd.DataFrame, config: dict) -> dict[str, str | None]:
    mode = config.get("column_matching", "exact")
    actual = {}
    for c in df.columns:
        actual.setdefault(normalize(c, mode), c)
    names = [c["name"] for c in config.get("columns", [])] + list(config.get("mandatory_columns", []))
    return {n: actual.get(normalize(n, mode)) for n in names}


def _record(outcome: ValidationOutcome, name, scope, column, expected, issues: list[Issue]):
    outcome.checks.append({"name": name, "scope": scope, "column": column, "expected": expected,
                           "status": "FAIL" if issues else "PASS", "issues": len(issues)})
    (outcome.file_issues if scope == "file" else outcome.issues).extend(issues)


def run_validation(df: pd.DataFrame, config: dict, filename: str, size_bytes: int) -> ValidationOutcome:
    ctx = Context(df=df, config=config, filename=filename, size_bytes=size_bytes)
    ctx.colmap = _resolve_columns(df, config)
    outcome = ValidationOutcome(status="PASS", total_rows=len(df), total_columns=len(df.columns))

    for fc_cls in FILE_CHECKS:
        fc = fc_cls()
        if fc.enabled(ctx):
            issues = fc.run(ctx)  # run first: some checks build their `expected` text while running
            _record(outcome, fc.name, "file", None, fc.expected, issues)

    for rule in config.get("columns", []):
        col = ctx.colmap.get(rule["name"])
        for cc in COLUMN_CHECKS:
            if not cc.enabled(rule):
                continue
            label = f"{cc.label}: {rule['name']}"
            if col is None:  # column absent -> cannot evaluate (mandatory check reports it if required)
                outcome.checks.append({"name": label, "scope": "column", "column": rule["name"],
                                       "expected": cc.expected(rule), "status": "SKIPPED", "issues": 0})
                continue
            _record(outcome, label, "column", col, cc.expected(rule), cc.run(ctx, rule, col))

    outcome.status = "FLAGGED" if outcome.checks_failed else "PASS"
    return outcome
