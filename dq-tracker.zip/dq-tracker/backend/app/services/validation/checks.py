"""Check implementations. One class per check type; register new ones in the lists at the bottom.

Adding a new column check:  subclass ColumnCheck, implement enabled/expected/is_valid, add to COLUMN_CHECKS.
Adding a new file check:    subclass FileCheck, implement run, add to FILE_CHECKS.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime

import pandas as pd


@dataclass
class Issue:
    rule: str
    expected: str
    column: str | None = None
    row: int | None = None
    value: str | None = None
    level: str = "cell"  # "cell" | "file"

    def to_dict(self) -> dict:
        return {"row": self.row, "column": self.column, "rule": self.rule,
                "value": self.value, "expected": self.expected, "level": self.level}


@dataclass
class Context:
    df: pd.DataFrame
    config: dict
    filename: str
    size_bytes: int
    colmap: dict[str, str | None] = field(default_factory=dict)  # rule column name -> actual df column

    @property
    def ext(self) -> str:
        return self.filename.rsplit(".", 1)[-1].lower() if "." in self.filename else ""


def normalize(name: str, mode: str) -> str:
    if mode == "case_insensitive":
        return str(name).strip().casefold()
    if mode == "ignore_spaces":
        return " ".join(str(name).split())
    return str(name)


def is_blank(v) -> bool:
    return v is None or str(v).strip() == ""


# ------------------------------------------------------------------ file-level checks
class FileCheck:
    name = ""
    expected = ""

    def enabled(self, ctx: Context) -> bool:
        return True

    def run(self, ctx: Context) -> list[Issue]:
        raise NotImplementedError


class FileTypeCheck(FileCheck):
    name = "Allowed file type"

    def enabled(self, ctx):
        return bool(ctx.config.get("allowed_file_types"))

    def run(self, ctx):
        allowed = ctx.config.get("allowed_file_types") or []
        self.expected = "File type must be one of: " + ", ".join("." + a for a in allowed)
        if ctx.ext not in allowed:
            return [Issue(self.name, self.expected, value=f".{ctx.ext}", level="file")]
        return []


class FileSizeCheck(FileCheck):
    name = "Maximum file size"

    def enabled(self, ctx):
        return ctx.config.get("max_file_size_mb") is not None

    def run(self, ctx):
        limit = float(ctx.config["max_file_size_mb"])
        self.expected = f"File size must not exceed {limit:g} MB"
        if ctx.size_bytes > limit * 1024 * 1024:
            return [Issue(self.name, self.expected, value=f"{ctx.size_bytes / 1024 / 1024:.2f} MB", level="file")]
        return []


class MandatoryColumnsCheck(FileCheck):
    name = "Mandatory columns"

    def enabled(self, ctx):
        return bool(ctx.config.get("mandatory_columns"))

    def run(self, ctx):
        mode = ctx.config.get("column_matching", "exact")
        self.expected = "Required columns: " + ", ".join(ctx.config["mandatory_columns"])
        issues = []
        loose = {normalize(c, "case_insensitive"): c for c in ctx.df.columns}
        for col in ctx.config["mandatory_columns"]:
            if ctx.colmap.get(col) is None:
                hint = loose.get(normalize(col, "case_insensitive"))
                value = f"(missing) found similar column '{hint}'" if hint and mode == "exact" else "(missing)"
                issues.append(Issue(self.name, f"Column '{col}' must exist (matching: {mode.replace('_', ' ')})",
                                    column=col, value=value, level="file"))
        return issues


class ExtraColumnsCheck(FileCheck):
    name = "No unexpected columns"
    expected = "File must only contain columns defined in the rule set"

    def enabled(self, ctx):
        return bool(ctx.config.get("disallow_extra_columns"))

    def run(self, ctx):
        known = {c for c in ctx.colmap.values() if c is not None}
        return [Issue(self.name, self.expected, column=c, value="(unexpected column)", level="file")
                for c in ctx.df.columns if c not in known]


class RowCountCheck(FileCheck):
    name = "Row count"

    def enabled(self, ctx):
        return ctx.config.get("min_rows") is not None or ctx.config.get("max_rows") is not None

    def run(self, ctx):
        lo, hi, n = ctx.config.get("min_rows"), ctx.config.get("max_rows"), len(ctx.df)
        parts = []
        if lo is not None:
            parts.append(f"at least {lo}")
        if hi is not None:
            parts.append(f"at most {hi}")
        self.expected = "Row count must be " + " and ".join(parts)
        if (lo is not None and n < lo) or (hi is not None and n > hi):
            return [Issue(self.name, self.expected, value=f"{n} rows", level="file")]
        return []


# ------------------------------------------------------------------ column-level checks
class ColumnCheck:
    key = ""
    label = ""
    skip_blank = True

    def enabled(self, rule: dict) -> bool:
        raise NotImplementedError

    def expected(self, rule: dict) -> str:
        raise NotImplementedError

    def is_valid(self, value: str, rule: dict) -> bool:
        raise NotImplementedError

    def run(self, ctx: Context, rule: dict, col: str) -> list[Issue]:
        exp = self.expected(rule)
        out = []
        for idx, v in ctx.df[col].items():
            if self.skip_blank and is_blank(v):
                continue
            if not self.is_valid(str(v), rule):
                out.append(Issue(self.label, exp, column=col, row=int(idx) + 2, value=str(v)))
        return out


class NotNullCheck(ColumnCheck):
    key, label, skip_blank = "not_null", "Not null", False

    def enabled(self, rule):
        return bool(rule.get("not_null"))

    def expected(self, rule):
        return "Value is required (cannot be empty)"

    def is_valid(self, value, rule):
        return not is_blank(value)


_BOOL = {"true", "false", "yes", "no", "y", "n", "t", "f", "1", "0"}
_INT = re.compile(r"^[+-]?\d+$")


class DataTypeCheck(ColumnCheck):
    key, label = "data_type", "Data type"

    def enabled(self, rule):
        return bool(rule.get("data_type"))

    def expected(self, rule):
        t = rule["data_type"]
        if t == "date":
            return f"Date in format {rule.get('date_format') or '%Y-%m-%d'}"
        return {"integer": "Whole number", "float": "Decimal number", "string": "Text", "boolean": "Boolean (true/false, yes/no, 1/0)"}[t]

    def is_valid(self, value, rule):
        v, t = value.strip(), rule["data_type"]
        if t == "string":
            return True
        if t == "integer":
            return bool(_INT.match(v))
        if t == "float":
            try:
                f = float(v)
                return f == f and f not in (float("inf"), float("-inf"))
            except ValueError:
                return False
        if t == "boolean":
            return v.lower() in _BOOL
        if t == "date":
            try:
                datetime.strptime(v, rule.get("date_format") or "%Y-%m-%d")
                return True
            except ValueError:
                return False
        return True


class UniqueCheck(ColumnCheck):
    key, label = "unique", "Unique"

    def enabled(self, rule):
        return bool(rule.get("unique"))

    def expected(self, rule):
        return "Value must be unique (no duplicates)"

    def run(self, ctx, rule, col):
        s = ctx.df[col].astype(str).str.strip()
        s = s[s != ""]
        dup = s[s.duplicated(keep=False)]
        return [Issue(self.label, self.expected(rule), column=col, row=int(i) + 2, value=v) for i, v in dup.items()]


class AllowedValuesCheck(ColumnCheck):
    key, label = "allowed_values", "Allowed values"

    def enabled(self, rule):
        return bool(rule.get("allowed_values"))

    def expected(self, rule):
        return "One of: " + ", ".join(rule["allowed_values"])

    def is_valid(self, value, rule):
        return value.strip() in {a.strip() for a in rule["allowed_values"]}


class NumericRangeCheck(ColumnCheck):
    key, label = "numeric_range", "Numeric range"

    def enabled(self, rule):
        return rule.get("min_value") is not None or rule.get("max_value") is not None

    def expected(self, rule):
        lo, hi = rule.get("min_value"), rule.get("max_value")
        if lo is not None and hi is not None:
            return f"Number between {lo:g} and {hi:g}"
        return f"Number >= {lo:g}" if lo is not None else f"Number <= {hi:g}"

    def is_valid(self, value, rule):
        try:
            f = float(value.strip())
        except ValueError:
            return False  # non-numeric cannot satisfy a numeric range
        lo, hi = rule.get("min_value"), rule.get("max_value")
        return (lo is None or f >= lo) and (hi is None or f <= hi)


class RegexCheck(ColumnCheck):
    key, label = "regex", "Regex pattern"

    def enabled(self, rule):
        return bool(rule.get("regex"))

    def expected(self, rule):
        return f"Must match pattern {rule['regex']}"

    def is_valid(self, value, rule):
        return re.search(rule["regex"], value.strip()) is not None


class StringLengthCheck(ColumnCheck):
    key, label = "string_length", "String length"

    def enabled(self, rule):
        return rule.get("min_length") is not None or rule.get("max_length") is not None

    def expected(self, rule):
        lo, hi = rule.get("min_length"), rule.get("max_length")
        if lo is not None and hi is not None:
            return f"Length between {lo} and {hi} characters"
        return f"At least {lo} characters" if lo is not None else f"At most {hi} characters"

    def is_valid(self, value, rule):
        n, lo, hi = len(value.strip()), rule.get("min_length"), rule.get("max_length")
        return (lo is None or n >= lo) and (hi is None or n <= hi)


# Registries: order here = order in the "Checks" list
FILE_CHECKS: list[type[FileCheck]] = [FileTypeCheck, FileSizeCheck, MandatoryColumnsCheck, ExtraColumnsCheck, RowCountCheck]  # instantiated per run (they hold per-run state)
COLUMN_CHECKS: list[ColumnCheck] = [NotNullCheck(), DataTypeCheck(), UniqueCheck(), AllowedValuesCheck(),
                                    NumericRangeCheck(), RegexCheck(), StringLengthCheck()]
