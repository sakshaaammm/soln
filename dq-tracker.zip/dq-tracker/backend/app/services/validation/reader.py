"""Reads uploaded CSV / Excel bytes into a DataFrame of strings, with clear errors."""
import io
from datetime import date, datetime

import pandas as pd


class FileReadError(Exception):
    def __init__(self, message: str, status_code: int = 422):
        super().__init__(message)
        self.message = message
        self.status_code = status_code


CSV_ENCODINGS = ("utf-8-sig", "cp1252", "latin-1")  # latin-1 never fails: last-resort fallback


def _cell_to_str(v) -> str:
    if v is None or (isinstance(v, float) and pd.isna(v)) or v is pd.NaT:
        return ""
    if isinstance(v, (datetime, pd.Timestamp)):
        return v.strftime("%Y-%m-%d") if (v.hour, v.minute, v.second) == (0, 0, 0) else v.strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(v, date):
        return v.strftime("%Y-%m-%d")
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v)


def read_tabular(content: bytes, ext: str) -> pd.DataFrame:
    if not content or not content.strip():
        raise FileReadError("The uploaded file is empty.")
    ext = ext.lower().lstrip(".")
    try:
        if ext == "csv":
            df = _read_csv(content)
        elif ext in ("xlsx", "xls"):
            df = _read_excel(content, ext)
        else:
            raise FileReadError(f"Unsupported file type '.{ext}'.", 415)
    except FileReadError:
        raise
    except Exception as e:  # corrupt / unexpected
        raise FileReadError(f"The file could not be read. It may be corrupt or not a valid .{ext} file ({type(e).__name__}).")

    if len(df.columns) == 0:
        raise FileReadError("The file has no header row or columns.")
    df.columns = [str(c).strip() if str(c).strip() else f"Unnamed_{i + 1}" for i, c in enumerate(df.columns)]
    # drop fully blank rows but KEEP original index so row numbers match the spreadsheet (index + 2)
    blank = df.apply(lambda r: all(str(x).strip() == "" for x in r), axis=1)
    df = df[~blank]
    return df


def _read_csv(content: bytes) -> pd.DataFrame:
    last_err: Exception | None = None
    for enc in CSV_ENCODINGS:
        try:
            return pd.read_csv(io.BytesIO(content), dtype=str, keep_default_na=False, encoding=enc)
        except UnicodeDecodeError as e:
            last_err = e
            continue
        except pd.errors.EmptyDataError:
            raise FileReadError("The CSV file is empty or has no header row.")
        except pd.errors.ParserError as e:
            raise FileReadError(f"The CSV file is malformed and could not be parsed: {str(e)[:200]}")
    raise FileReadError(f"Could not decode the file (unsupported encoding): {last_err}")


def _read_excel(content: bytes, ext: str) -> pd.DataFrame:
    engine = "openpyxl" if ext == "xlsx" else "xlrd"
    try:
        raw = pd.read_excel(io.BytesIO(content), sheet_name=0, dtype=object, header=0, engine=engine)
    except Exception as e:
        raise FileReadError(f"The Excel file could not be opened. It may be corrupt, password-protected or not a real .{ext} file.")
    return raw.apply(lambda col: col.map(_cell_to_str))
