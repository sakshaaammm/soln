import json
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import BASE_DIR, settings
from app.core.database import Base, SessionLocal, engine
from app.core.security import hash_password
from app.models import Role, RuleSet, User
from app.routers import auth, rulesets, uploads, users
from app.schemas import RuleConfig


def seed(db):
    """Default admin from .env (first startup) + a sample rule set for testing."""
    if not db.query(User).filter(User.role == Role.ADMIN.value).first():
        db.add(User(username=settings.DEFAULT_ADMIN_USERNAME, email=settings.DEFAULT_ADMIN_EMAIL.lower(),
                    hashed_password=hash_password(settings.DEFAULT_ADMIN_PASSWORD), role=Role.ADMIN.value))
        db.commit()
    sample = BASE_DIR / "samples" / "sample_ruleset.json"
    if settings.SEED_SAMPLE_RULESET and sample.exists() and db.query(RuleSet).count() == 0:
        data = json.loads(sample.read_text())
        db.add(RuleSet(name=data["name"], description=data["description"], is_active=True,
                       config=RuleConfig(**data["config"]).model_dump()))
        db.commit()


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)  # swap for Alembic migrations when moving to PostgreSQL
    for sub in ("uploads", "reports"):
        (settings.storage_path / sub).mkdir(parents=True, exist_ok=True)
    with SessionLocal() as db:
        seed(db)
    yield


app = FastAPI(title="Data Quality File Tracker", version="1.0.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=settings.cors_list, allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"], expose_headers=["Content-Disposition"])

for r in (auth.router, users.router, rulesets.router, uploads.router):
    app.include_router(r)


@app.get("/health", tags=["meta"])
def health():
    return {"status": "ok"}
