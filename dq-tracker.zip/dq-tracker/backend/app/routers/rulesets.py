from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.deps import require_admin, require_any
from app.models import Role, RuleSet, Upload, User
from app.schemas import RuleSetCreate, RuleSetOut, RuleSetStatus, RuleSetUpdate

router = APIRouter(prefix="/rulesets", tags=["rulesets"])


def _get_visible(db: Session, rs_id: int, user: User) -> RuleSet:
    rs = db.get(RuleSet, rs_id)
    if not rs or (user.role != Role.ADMIN.value and not rs.is_active):
        raise HTTPException(404, "Rule set not found")
    return rs


def _check_name_free(db: Session, name: str, exclude_id: int | None = None):
    q = db.query(RuleSet).filter(func.lower(RuleSet.name) == name.strip().lower())
    if exclude_id:
        q = q.filter(RuleSet.id != exclude_id)
    if q.first():
        raise HTTPException(status.HTTP_409_CONFLICT, "A rule set with this name already exists")


@router.get("", response_model=list[RuleSetOut])
def list_rulesets(db: Session = Depends(get_db), user: User = Depends(require_any)):
    q = db.query(RuleSet)
    if user.role != Role.ADMIN.value:  # analysts only ever see active rule sets
        q = q.filter(RuleSet.is_active.is_(True))
    return q.order_by(RuleSet.name).all()


@router.get("/{rs_id}", response_model=RuleSetOut)
def get_ruleset(rs_id: int, db: Session = Depends(get_db), user: User = Depends(require_any)):
    return _get_visible(db, rs_id, user)


@router.post("", response_model=RuleSetOut, status_code=201)
def create_ruleset(body: RuleSetCreate, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    _check_name_free(db, body.name)
    rs = RuleSet(name=body.name.strip(), description=body.description, is_active=body.is_active,
                 config=body.config.model_dump(), created_by=admin.id)
    db.add(rs)
    db.commit()
    db.refresh(rs)
    return rs


@router.put("/{rs_id}", response_model=RuleSetOut)
def update_ruleset(rs_id: int, body: RuleSetUpdate, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    rs = db.get(RuleSet, rs_id)
    if not rs:
        raise HTTPException(404, "Rule set not found")
    _check_name_free(db, body.name, rs_id)
    rs.name, rs.description, rs.is_active = body.name.strip(), body.description, body.is_active
    rs.config = body.config.model_dump()
    db.commit()
    db.refresh(rs)
    return rs


@router.patch("/{rs_id}/status", response_model=RuleSetOut)
def set_status(rs_id: int, body: RuleSetStatus, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    rs = db.get(RuleSet, rs_id)
    if not rs:
        raise HTTPException(404, "Rule set not found")
    rs.is_active = body.is_active
    db.commit()
    db.refresh(rs)
    return rs


@router.delete("/{rs_id}", status_code=204)
def delete_ruleset(rs_id: int, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    rs = db.get(RuleSet, rs_id)
    if not rs:
        raise HTTPException(404, "Rule set not found")
    # keep upload history; rule set name is snapshotted on each upload
    db.query(Upload).filter(Upload.ruleset_id == rs_id).update({Upload.ruleset_id: None})
    db.delete(rs)
    db.commit()
