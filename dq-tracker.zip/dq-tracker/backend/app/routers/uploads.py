import re
import uuid
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session, joinedload

from app.core.config import settings
from app.core.database import get_db
from app.core.deps import require_any
from app.models import Role, RuleSet, Upload, User, ValidationResult
from app.schemas import ResultOut, StatsOut, UploadDetail, UploadOut
from app.services.validation import (MAX_STORED_ISSUES, FileReadError, build_flagged_report, read_tabular,
                                     run_validation)

router = APIRouter(prefix="/uploads", tags=["uploads"])
ALLOWED_EXT = {"csv", "xlsx", "xls"}


def _to_out(u: Upload) -> UploadOut:
    return UploadOut(id=u.id, original_filename=u.original_filename, ruleset_id=u.ruleset_id,
                     ruleset_name=u.ruleset_name, status=u.status, file_size=u.file_size, created_at=u.created_at,
                     user_id=u.user_id, username=u.user.username,
                     issue_count=u.result.issue_count if u.result else 0,
                     has_report=bool(u.report_path and Path(u.report_path).exists()))


def _to_detail(u: Upload) -> UploadDetail:
    r = u.result
    result = ResultOut(total_rows=r.total_rows, total_columns=r.total_columns, checks_passed=r.checks_passed,
                       checks_failed=r.checks_failed, issue_count=r.issue_count, issues_truncated=r.issues_truncated,
                       file_issues=r.file_issues, issues=r.issues, checks=r.checks) if r else None
    return UploadDetail(**_to_out(u).model_dump(), result=result)


def _query(db: Session, user: User):
    q = db.query(Upload).options(joinedload(Upload.user), joinedload(Upload.result))
    return q if user.role == Role.ADMIN.value else q.filter(Upload.user_id == user.id)


def _get_allowed(db: Session, upload_id: int, user: User) -> Upload:
    u = _query(db, user).filter(Upload.id == upload_id).first()
    if not u:  # analysts get 404 (not 403) for other people's uploads
        raise HTTPException(404, "Upload not found")
    return u


@router.get("/stats", response_model=StatsOut)
def stats(db: Session = Depends(get_db), user: User = Depends(require_any)):
    base = _query(db, user)
    total = base.count()
    passed = base.filter(Upload.status == "PASS").count()
    recent = base.order_by(Upload.created_at.desc()).limit(5).all()
    out = StatsOut(total_uploads=total, passed=passed, flagged=total - passed, recent=[_to_out(u) for u in recent])
    if user.role == Role.ADMIN.value:
        out.analysts = db.query(User).filter(User.role == Role.DATA_ANALYST.value).count()
        out.active_rulesets = db.query(RuleSet).filter(RuleSet.is_active.is_(True)).count()
    return out


@router.post("", response_model=UploadDetail, status_code=201)
def create_upload(file: UploadFile = File(...), ruleset_id: int = Form(...),
                  db: Session = Depends(get_db), user: User = Depends(require_any)):
    rs = db.get(RuleSet, ruleset_id)
    if not rs or (not rs.is_active and user.role != Role.ADMIN.value):
        raise HTTPException(404, "Rule set not found or not active")
    config = rs.config or {}

    filename = Path(file.filename or "upload").name
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    allowed = set(config.get("allowed_file_types") or ALLOWED_EXT) & ALLOWED_EXT
    if ext not in allowed:
        raise HTTPException(415, f"File type '.{ext or '?'}' is not allowed for this rule set. Allowed: "
                                 + ", ".join("." + a for a in sorted(allowed)))

    limit_mb = min(float(config.get("max_file_size_mb") or settings.MAX_UPLOAD_MB), settings.MAX_UPLOAD_MB)
    content = file.file.read(int(limit_mb * 1024 * 1024) + 1)
    if len(content) > limit_mb * 1024 * 1024:
        raise HTTPException(413, f"File is too large. Maximum size for this rule set is {limit_mb:g} MB.")

    try:
        df = read_tabular(content, ext)
    except FileReadError as e:
        raise HTTPException(e.status_code, e.message)

    outcome = run_validation(df, config, filename, len(content))

    # persist file + metadata
    safe = re.sub(r"[^A-Za-z0-9._-]", "_", filename)
    udir = settings.storage_path / "uploads" / str(user.id)
    udir.mkdir(parents=True, exist_ok=True)
    stored = udir / f"{uuid.uuid4().hex}_{safe}"
    stored.write_bytes(content)

    upload = Upload(user_id=user.id, ruleset_id=rs.id, ruleset_name=rs.name, original_filename=filename,
                    stored_path=str(stored), file_size=len(content), status=outcome.status)
    db.add(upload)
    db.flush()

    all_issues = [i.to_dict() for i in outcome.issues]
    upload.result = ValidationResult(
        total_rows=outcome.total_rows, total_columns=outcome.total_columns, checks_passed=outcome.checks_passed,
        checks_failed=outcome.checks_failed, issue_count=outcome.issue_count,
        issues_truncated=len(all_issues) > MAX_STORED_ISSUES, issues=all_issues[:MAX_STORED_ISSUES],
        file_issues=[i.to_dict() for i in outcome.file_issues], checks=outcome.checks)

    if outcome.status == "FLAGGED":
        report = settings.storage_path / "reports" / str(user.id) / f"upload_{upload.id}_flagged_report.xlsx"
        build_flagged_report(df, outcome, report)
        upload.report_path = str(report)

    db.commit()
    return _to_detail(_get_allowed(db, upload.id, user))


@router.get("", response_model=list[UploadOut])
def list_uploads(status: str | None = None, limit: int = 500, db: Session = Depends(get_db),
                 user: User = Depends(require_any)):
    q = _query(db, user)
    if status in ("PASS", "FLAGGED"):
        q = q.filter(Upload.status == status)
    return [_to_out(u) for u in q.order_by(Upload.created_at.desc()).limit(min(limit, 2000)).all()]


@router.get("/{upload_id}", response_model=UploadDetail)
def get_upload(upload_id: int, db: Session = Depends(get_db), user: User = Depends(require_any)):
    return _to_detail(_get_allowed(db, upload_id, user))


@router.get("/{upload_id}/download")
def download_report(upload_id: int, db: Session = Depends(get_db), user: User = Depends(require_any)):
    u = _get_allowed(db, upload_id, user)
    if u.status != "FLAGGED" or not u.report_path or not Path(u.report_path).exists():
        raise HTTPException(404, "No flagged report is available for this upload")
    stem = Path(u.original_filename).stem
    return FileResponse(u.report_path, filename=f"flagged_report_{stem}.xlsx",
                        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
