# Data Quality File Tracker

Upload a CSV/Excel file, validate it against an admin-defined rule set, and get **PASS** or **FLAGGED**.
Flagged files come with a downloadable `.xlsx` report (red cells + comments, issue summary, per-check results).

**Stack:** React (Vite) · React Router · Axios · Tailwind | FastAPI · SQLAlchemy (SQLite, PostgreSQL-ready) · pandas/openpyxl · JWT (python-jose) · bcrypt (passlib)

## Setup

### 1. Backend (Python 3.11+)
```bash
cd backend
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                   # then set SECRET_KEY
uvicorn app.main:app --reload --port 8000
```
API docs: http://localhost:8000/docs. On first startup the database is created, the default admin is
seeded from `.env`, and the sample rule set "Customer Data Standard" is added (turn off with `SEED_SAMPLE_RULESET=false`).

### 2. Frontend (Node 18+)
```bash
cd frontend
npm install
cp .env.example .env        # VITE_API_URL=http://localhost:8000
npm run dev                 # http://localhost:5173
```

## Default admin login
Username `admin` (or `admin@example.com`) / password `Admin@12345`, from `DEFAULT_ADMIN_*` in `backend/.env`. **Change these before any real use.**
Log in as admin → **Analysts** → create a Data Analyst account → log in as that analyst.

## Try it (PASS and FLAGGED)
Log in as an analyst, open **Validate a file**, pick *Customer Data Standard*, and upload from `backend/samples/`:

| File | Expected result |
|---|---|
| `customers_pass.csv` | PASS |
| `customers_flagged.csv` | FLAGGED: bad ID format, short name, bad email, duplicate ID/email, age out of range, wrong date formats, disallowed status, bad boolean, negative balance, empty required value, unexpected `notes` column |
| `customers_missing_column.csv` | FLAGGED: mandatory columns missing, plus the unexpected-column and column checks that can still run |

`sample_ruleset.json` shows the rule-set JSON structure (also visible via the Admin → Rule sets form).

## Layout
```
backend/app
  main.py                      app, CORS, startup seeding
  core/    config.py security.py database.py deps.py   (deps.py = role guards on every route)
  models/  schemas/  routers/  (auth, users, rulesets, uploads)
  services/validation/
    reader.py   CSV/Excel -> DataFrame, encoding + corrupt-file handling
    checks.py   one class per check type (registries at the bottom)
    engine.py   runs checks, builds the outcome
    report.py   flagged .xlsx (Data / Issue Summary / Checks)
frontend/src   pages/ components/ api/ context/AuthContext.jsx
```

## Adding a new check type
In `checks.py`, subclass `ColumnCheck` (implement `enabled`, `expected`, `is_valid`) or `FileCheck`, add it to
`COLUMN_CHECKS` / `FILE_CHECKS`, and add the field to `ColumnRule` / `RuleConfig` in `schemas/schemas.py`.
The engine, results screen and report pick it up automatically.

## Notes
- **Access control** is enforced server-side: admin-only routes use `require_admin`; analysts only see active rule sets and their own uploads (other users' uploads return 404).
- **Rows** in results/reports use spreadsheet row numbers (header = row 1). All values are validated as text, and the report's Data sheet stores them as text.
- Excel files: only the first sheet is checked. Blank rows are ignored.
- Cell issues stored in the DB are capped at 5,000 per upload; the Excel report always contains every issue.
- **PostgreSQL:** `pip install psycopg2-binary`, set `DATABASE_URL=postgresql+psycopg2://...`. Tables are created with `create_all`; use Alembic for later migrations.
- Use a long random `SECRET_KEY` and HTTPS in production.
