# Data Quality File Tracker — Backend

Python 3.11+ / FastAPI / SQLAlchemy / SQLite. Copy `.env.example` to `.env` and change `SECRET_KEY` and the default admin password before use.

```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```

API docs: http://localhost:8000/docs

The admin is seeded on first startup using `DEFAULT_ADMIN_*` values in `.env`. Uploaded originals and flagged workbooks are stored in `storage/`. For PostgreSQL, set `DATABASE_URL` to a PostgreSQL SQLAlchemy URL and install the appropriate PostgreSQL driver.
