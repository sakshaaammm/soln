from pathlib import Path
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.config import settings
from app.core.database import Base, engine, SessionLocal
from app.core.security import hash_password
from app.models import User
from app.routers import auth, users, rulesets, uploads

Base.metadata.create_all(bind=engine)
Path(settings.upload_dir).mkdir(parents=True, exist_ok=True)
Path(settings.report_dir).mkdir(parents=True, exist_ok=True)

def seed_admin():
    db = SessionLocal()
    try:
        if not db.query(User).filter(User.role == "ADMIN").first():
            db.add(User(username=settings.default_admin_username, email=settings.default_admin_email,
                        password_hash=hash_password(settings.default_admin_password), role="ADMIN"))
            db.commit()
    finally: db.close()
seed_admin()

app = FastAPI(title="Data Quality File Tracker", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=[settings.frontend_origin], allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])
app.include_router(auth.router)
app.include_router(users.router)
app.include_router(rulesets.router)
app.include_router(uploads.router)

@app.get("/health")
def health():
    return {"status":"ok"}
