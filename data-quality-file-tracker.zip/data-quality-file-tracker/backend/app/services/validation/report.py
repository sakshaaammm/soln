from openpyxl import Workbook, load_workbook
from openpyxl.styles import PatternFill, Font
from openpyxl.comments import Comment
from openpyxl.utils.dataframe import dataframe_to_rows
import pandas as pd
from pathlib import Path

RED = PatternFill(start_color="FFFFC7CE", end_color="FFFFC7CE", fill_type="solid")

def build_report(df: pd.DataFrame, result: dict, rules: dict, path: str):
    wb = Workbook()
    ws = wb.active
    ws.title = "Data"
    for row in dataframe_to_rows(df, index=False, header=True): ws.append(row)
    headers = {str(c.value): c.column for c in ws[1]}
    ws.cell(1, len(headers)+1, "Issues")
    by_row = {}
    for issue in result["issues"]:
        r = issue.get("row")
        if r is not None:
            by_row.setdefault(r, []).append(issue)
            col_idx = headers.get(str(issue.get("column")))
            if col_idx and 1 < r <= ws.max_row:
                cell = ws.cell(r, col_idx)
                cell.fill = RED
                cell.comment = Comment(f"{issue['rule']}. Expected: {issue['expected']}", "Data Quality Tracker")
    for r, items in by_row.items():
        if r <= ws.max_row:
            ws.cell(r, len(headers)+1, " | ".join(f"{x['column']}: {x['rule']}" for x in items))
    summary = wb.create_sheet("Issue Summary")
    summary.append(["Row", "Column", "Rule", "Actual value", "Expected"])
    for x in result["issues"]:
        summary.append([x.get("row") or "File", x.get("column"), x.get("rule"), str(x.get("value", "")), x.get("expected")])
    checks = wb.create_sheet("Checks")
    checks.append(["Rule", "Status", "Expected"])
    for x in result["checks"]: checks.append([x["rule"], x["status"], x["expected"]])
    for sheet in wb.worksheets:
        sheet.freeze_panes = "A2"
        sheet.auto_filter.ref = sheet.dimensions
        for cell in sheet[1]:
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill(start_color="FF243247", end_color="FF243247", fill_type="solid")
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)
