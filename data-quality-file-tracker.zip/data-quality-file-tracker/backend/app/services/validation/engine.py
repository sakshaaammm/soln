import re
import pandas as pd

def _empty(v):
    return pd.isna(v) or (isinstance(v, str) and not v.strip())

def validate_dataframe(df: pd.DataFrame, rules: dict) -> dict:
    issues, checks = [], []
    columns = list(df.columns)
    matching = rules.get("column_matching", "case_insensitive")
    def norm(x):
        x = str(x)
        if matching in ("ignore_spaces", "ignore_extra_spaces"):
            x = " ".join(x.split())
        if matching in ("case_insensitive", "ignore_spaces", "ignore_extra_spaces"):
            x = x.casefold()
        return x
    col_lookup = {norm(c): c for c in columns}
    def add_check(name, passed, expected):
        checks.append({"rule": name, "status": "PASS" if passed else "FAIL", "expected": expected})
    mandatory = rules.get("mandatory_columns", [])
    missing = [c for c in mandatory if norm(c) not in col_lookup]
    add_check("Mandatory columns", not missing, f"Columns present: {mandatory}")
    for c in missing:
        issues.append({"row": None, "column": c, "rule": "Missing mandatory column", "value": "", "expected": "Column must exist"})
    if rules.get("disallow_extra_columns"):
        extras = [c for c in columns if norm(c) not in {norm(x) for x in mandatory}]
        add_check("Unexpected columns", not extras, f"Only expected columns: {mandatory}")
        for c in extras:
            issues.append({"row": None, "column": c, "rule": "Unexpected column", "value": c, "expected": "Remove this column"})
    min_rows, max_rows = rules.get("min_rows"), rules.get("max_rows")
    if min_rows is not None:
        ok = len(df) >= int(min_rows); add_check("Minimum row count", ok, f">= {min_rows}")
        if not ok: issues.append({"row": None, "column": "", "rule": "Minimum row count", "value": len(df), "expected": f">= {min_rows}"})
    if max_rows is not None:
        ok = len(df) <= int(max_rows); add_check("Maximum row count", ok, f"<= {max_rows}")
        if not ok: issues.append({"row": None, "column": "", "rule": "Maximum row count", "value": len(df), "expected": f"<= {max_rows}"})
    column_rules = rules.get("columns", {})
    for requested, spec in column_rules.items():
        actual_col = col_lookup.get(norm(requested))
        if actual_col is None:
            # Missing column is already handled by mandatory columns; report configured checks too.
            add_check(f"{requested}: configured checks", False, "Column must exist")
            continue
        local_before = len(issues)
        s = df[actual_col]
        if spec.get("not_null"):
            bad = s.map(_empty)
            for i in df.index[bad]:
                issues.append({"row": int(i)+2, "column": actual_col, "rule": "Not null", "value": "", "expected": "Non-empty value"})
            add_check(f"{requested}: not null", not bad.any(), "Non-empty values")
        dtype = spec.get("type")
        if dtype:
            for i, val in s.items():
                if _empty(val): continue
                ok = True
                if dtype == "integer":
                    try: ok = float(val).is_integer()
                    except (ValueError, TypeError): ok = False
                elif dtype == "float":
                    try: float(val)
                    except (ValueError, TypeError): ok = False
                elif dtype == "date":
                    try: pd.to_datetime(val, format=spec.get("date_format") or None, errors="raise")
                    except (ValueError, TypeError): ok = False
                elif dtype == "boolean":
                    ok = str(val).strip().casefold() in ("true","false","1","0","yes","no","y","n")
                elif dtype == "string":
                    ok = isinstance(val, str) or not isinstance(val, (int, float))
                if not ok:
                    issues.append({"row": int(i)+2, "column": actual_col, "rule": f"Data type: {dtype}", "value": str(val), "expected": f"Valid {dtype}"})
            add_check(f"{requested}: type {dtype}", not any(x["rule"] == f"Data type: {dtype}" and x["column"] == actual_col for x in issues), f"{dtype}")
        if spec.get("unique"):
            dup = s.notna() & s.duplicated(keep=False)
            for i in df.index[dup]:
                issues.append({"row": int(i)+2, "column": actual_col, "rule": "Unique", "value": str(df.at[i, actual_col]), "expected": "Unique value"})
            add_check(f"{requested}: unique", not dup.any(), "No duplicates")
        if "allowed_values" in spec and spec["allowed_values"] is not None:
            allowed = [str(v) for v in spec["allowed_values"]]
            bad = s.notna() & ~s.astype(str).isin(allowed)
            for i in df.index[bad]:
                issues.append({"row": int(i)+2, "column": actual_col, "rule": "Allowed values", "value": str(df.at[i, actual_col]), "expected": ", ".join(allowed)})
            add_check(f"{requested}: allowed values", not bad.any(), f"One of {allowed}")
        if spec.get("min") is not None or spec.get("max") is not None:
            nums = pd.to_numeric(s, errors="coerce")
            bad = nums.isna() & s.map(lambda v: not _empty(v))
            if spec.get("min") is not None: bad |= nums.notna() & (nums < float(spec["min"]))
            if spec.get("max") is not None: bad |= nums.notna() & (nums > float(spec["max"]))
            for i in df.index[bad]:
                issues.append({"row": int(i)+2, "column": actual_col, "rule": "Numeric range", "value": str(df.at[i, actual_col]), "expected": f"{spec.get('min', '-∞')} to {spec.get('max', '∞')}"})
            add_check(f"{requested}: numeric range", not bad.any(), f"{spec.get('min', '-∞')} to {spec.get('max', '∞')}")
        if spec.get("regex"):
            pattern = spec["regex"]
            bad = s.notna() & ~s.astype(str).map(lambda v: re.fullmatch(pattern, v) is not None)
            for i in df.index[bad]:
                issues.append({"row": int(i)+2, "column": actual_col, "rule": "Regex pattern", "value": str(df.at[i, actual_col]), "expected": pattern})
            add_check(f"{requested}: regex", not bad.any(), pattern)
        if spec.get("min_length") is not None or spec.get("max_length") is not None:
            lens = s.astype(str).str.len()
            bad = s.notna() & ((lens < int(spec.get("min_length", 0))) | (lens > int(spec.get("max_length", 10**9))))
            for i in df.index[bad]:
                issues.append({"row": int(i)+2, "column": actual_col, "rule": "String length", "value": str(df.at[i, actual_col]), "expected": f"{spec.get('min_length', 0)} to {spec.get('max_length', '∞')} characters"})
            add_check(f"{requested}: string length", not bad.any(), "Within configured length")
    return {"issues": issues, "checks": checks, "total_rows": len(df), "total_columns": len(df.columns),
            "checks_passed": sum(c["status"] == "PASS" for c in checks),
            "checks_failed": sum(c["status"] == "FAIL" for c in checks)}
