import json, uuid
from pathlib import Path
import pandas as pd
from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from app.core.config import settings
from app.core.database import get_db
from app.core.security import get_current_user, require_role
from app.models.user import User
from app.models.ruleset import RuleSet
from app.models.upload import Upload
from app.services.validation.engine import validate_dataframe
from app.services.validation.report import build_report

router = APIRouter(prefix="/uploads", tags=["uploads"])
ALLOWED = {".csv", ".xlsx", ".xls"}

def visible(u, user):
    if user.role == "ADMIN" or u.user_id == user.id: return True
    return False

@router.post("")
async def create_upload(file: UploadFile = File(...), ruleset_id: int = Form(...),
                        db: Session = Depends(get_db), user: User = Depends(require_role("ADMIN", "DATA_ANALYST"))):
    ext = Path(file.filename or "").suffix.lower()
    if ext not in ALLOWED: raise HTTPException(400, detail="Unsupported file type. Upload CSV, XLSX, or XLS.")
    content = await file.read()
    if not content: raise HTTPException(400, detail="The uploaded file is empty.")
    if len(content) > settings.max_upload_mb * 1024 * 1024: raise HTTPException(413, detail=f"File exceeds {settings.max_upload_mb} MB limit.")
    rs = db.query(RuleSet).filter(RuleSet.id == ruleset_id, RuleSet.is_active.is_(True)).first()
    if not rs: raise HTTPException(404, detail="Active rule set not found")
    rules = json.loads(rs.rules_json or "{}")
    allowed_types = rules.get("allowed_file_types", [".csv", ".xlsx", ".xls"])
    if ext not in allowed_types: raise HTTPException(400, detail=f"This rule set does not allow {ext} files.")
    max_mb = rules.get("max_file_size_mb")
    if max_mb and len(content) > int(max_mb) * 1024 * 1024: raise HTTPException(413, detail=f"File exceeds this rule set's {max_mb} MB limit.")
    path = Path(settings.upload_dir) / str(user.id) / f"{uuid.uuid4().hex}_{Path(file.filename).name}"
    path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(content)
    try:
        if ext == ".csv":
            try: df = pd.read_csv(path, encoding="utf-8-sig")
            except UnicodeDecodeError: df = pd.read_csv(path, encoding="latin-1")
        else:
            df = pd.read_excel(path, engine="xlrd" if ext == ".xls" else "openpyxl")
    except HTTPException: raise
    except Exception as e:
        path.unlink(missing_ok=True)
        raise HTTPException(400, detail=f"Could not read file. Check that it is a valid, non-empty CSV/XLSX file. Details: {str(e)[:180]}")
    if len(df.columns) == 0:
        raise HTTPException(400, detail="No columns were found in this file.")
    result = validate_dataframe(df, rules)
    report_path = None
    status = "PASS" if len(result["issues"]) == 0 else "FLAGGED"
    if status == "FLAGGED":
        report_path = str(Path(settings.report_dir) / str(user.id) / f"upload_{uuid.uuid4().hex}.xlsx")
        build_report(df, result, rules, report_path)
    rec = Upload(user_id=user.id, ruleset_id=rs.id, file_name=Path(file.filename).name, stored_path=str(path),
        report_path=report_path, status=status, total_rows=result["total_rows"], total_columns=result["total_columns"],
        checks_passed=result["checks_passed"], checks_failed=result["checks_failed"], issue_count=len(result["issues"]),
        result_json=json.dumps(result, default=str))
    db.add(rec); db.commit(); db.refresh(rec)
    return serialize(rec, rs.name)

def serialize(u, ruleset_name=None):
    result = json.loads(u.result_json or "{}")
    return {"id":u.id,"file_name":u.file_name,"ruleset_id":u.ruleset_id,"ruleset_name":ruleset_name,
        "status":u.status,"total_rows":u.total_rows,"total_columns":u.total_columns,
        "checks_passed":u.checks_passed,"checks_failed":u.checks_failed,"issue_count":u.issue_count,
        "created_at":u.created_at.isoformat() if u.created_at else None,"issues":result.get("issues",[]),"checks":result.get("checks",[])}

@router.get("")
def list_uploads(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    q = db.query(Upload)
    if user.role != "ADMIN": q = q.filter(Upload.user_id == user.id)
    rows = q.order_by(Upload.created_at.desc()).all()
    return [serialize(u, db.query(RuleSet).filter(RuleSet.id == u.ruleset_id).first().name) for u in rows]

@router.get("/{upload_id}")
def get_upload(upload_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    u = db.query(Upload).filter(Upload.id == upload_id).first()
    if not u or not visible(u, user): raise HTTPException(404, detail="Upload not found")
    rs = db.query(RuleSet).filter(RuleSet.id == u.ruleset_id).first()
    return serialize(u, rs.name if rs else "Deleted rule set")

@router.get("/{upload_id}/download")
def download_report(upload_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    u = db.query(Upload).filter(Upload.id == upload_id).first()
    if not u or not visible(u, user): raise HTTPException(404, detail="Upload not found")
    if u.status != "FLAGGED" or not u.report_path or not Path(u.report_path).exists():
        raise HTTPException(404, detail="No flagged report is available for this upload")
    return FileResponse(u.report_path, filename=f"flagged_report_{u.id}.xlsx",
                        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
