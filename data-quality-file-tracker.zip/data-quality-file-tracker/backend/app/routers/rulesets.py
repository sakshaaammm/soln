import json
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.core.security import get_current_user, require_role
from app.models.user import User
from app.models.ruleset import RuleSet
from app.schemas import RuleSetIn, RuleSetOut

router = APIRouter(prefix="/rulesets", tags=["rule sets"])

def out(r):
    return {"id": r.id, "name": r.name, "description": r.description, "is_active": r.is_active, "rules": json.loads(r.rules_json or "{}")}

@router.get("")
def list_rulesets(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    q = db.query(RuleSet)
    if user.role != "ADMIN": q = q.filter(RuleSet.is_active.is_(True))
    return [out(r) for r in q.order_by(RuleSet.created_at.desc()).all()]

@router.post("", response_model=RuleSetOut)
def create_ruleset(body: RuleSetIn, db: Session = Depends(get_db), admin: User = Depends(require_role("ADMIN"))):
    if db.query(RuleSet).filter(RuleSet.name == body.name).first(): raise HTTPException(409, detail="Rule set name already exists")
    r = RuleSet(name=body.name, description=body.description, is_active=body.is_active, rules_json=json.dumps(body.rules), created_by=admin.id)
    db.add(r); db.commit(); db.refresh(r)
    return out(r)

@router.get("/{ruleset_id}")
def get_ruleset(ruleset_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    r = db.query(RuleSet).filter(RuleSet.id == ruleset_id).first()
    if not r or (user.role != "ADMIN" and not r.is_active): raise HTTPException(404, detail="Rule set not found")
    return out(r)

@router.put("/{ruleset_id}")
def update_ruleset(ruleset_id: int, body: RuleSetIn, db: Session = Depends(get_db), admin: User = Depends(require_role("ADMIN"))):
    r = db.query(RuleSet).filter(RuleSet.id == ruleset_id).first()
    if not r: raise HTTPException(404, detail="Rule set not found")
    r.name=body.name; r.description=body.description; r.is_active=body.is_active; r.rules_json=json.dumps(body.rules)
    db.commit(); db.refresh(r); return out(r)

@router.delete("/{ruleset_id}")
def delete_ruleset(ruleset_id: int, db: Session = Depends(get_db), admin: User = Depends(require_role("ADMIN"))):
    r = db.query(RuleSet).filter(RuleSet.id == ruleset_id).first()
    if not r: raise HTTPException(404, detail="Rule set not found")
    if db.query(__import__("app.models.upload", fromlist=["Upload"]).Upload).filter_by(ruleset_id=r.id).first():
        r.is_active=False; db.commit()
        return {"message":"Rule set has uploads, so it was deactivated instead of physically deleted"}
    db.delete(r); db.commit(); return {"message":"Rule set deleted"}
