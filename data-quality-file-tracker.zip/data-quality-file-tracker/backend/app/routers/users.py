from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.core.security import require_role, hash_password
from app.models.user import User
from app.schemas import UserCreate, UserOut

router = APIRouter(prefix="/users", tags=["users"])

@router.post("", response_model=UserOut)
def create_user(body: UserCreate, db: Session = Depends(get_db), admin: User = Depends(require_role("ADMIN"))):
    if body.role != "DATA_ANALYST":
        raise HTTPException(400, detail="Only DATA_ANALYST accounts can be created here")
    if db.query(User).filter((User.username == body.username) | (User.email == body.email)).first():
        raise HTTPException(409, detail="Username or email already exists")
    user = User(username=body.username, email=str(body.email), password_hash=hash_password(body.password), role="DATA_ANALYST")
    db.add(user); db.commit(); db.refresh(user)
    return user

@router.get("", response_model=list[UserOut])
def list_users(db: Session = Depends(get_db), admin: User = Depends(require_role("ADMIN"))):
    return db.query(User).order_by(User.created_at.desc()).all()

@router.patch("/{user_id}/active", response_model=UserOut)
def set_active(user_id: int, active: bool, db: Session = Depends(get_db), admin: User = Depends(require_role("ADMIN"))):
    user = db.query(User).filter(User.id == user_id).first()
    if not user: raise HTTPException(404, detail="User not found")
    if user.role == "ADMIN": raise HTTPException(400, detail="Admin account cannot be disabled here")
    user.is_active = active; db.commit(); db.refresh(user)
    return user
