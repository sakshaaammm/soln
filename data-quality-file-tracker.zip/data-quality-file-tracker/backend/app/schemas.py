from pydantic import BaseModel, EmailStr, Field
from typing import Any

class LoginRequest(BaseModel):
    username: str
    password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str

class UserCreate(BaseModel):
    username: str = Field(min_length=3, max_length=80)
    email: EmailStr
    password: str = Field(min_length=8)
    role: str = "DATA_ANALYST"

class UserOut(BaseModel):
    id: int
    username: str
    email: EmailStr
    role: str
    is_active: bool
    class Config:
        from_attributes = True

class RuleSetIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    description: str = ""
    is_active: bool = True
    rules: dict[str, Any] = Field(default_factory=dict)

class RuleSetOut(BaseModel):
    id: int
    name: str
    description: str
    is_active: bool
    rules: dict[str, Any]
    class Config:
        from_attributes = True
