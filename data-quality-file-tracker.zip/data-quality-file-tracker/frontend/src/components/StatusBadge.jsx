export default function StatusBadge({ status }) {
 const pass = status === 'PASS'
 return <span className={`rounded-full px-2.5 py-1 text-xs font-bold ${pass ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}`}>{status}</span>
}
