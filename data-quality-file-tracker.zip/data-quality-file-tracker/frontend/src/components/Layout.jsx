import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
export default function Layout({ children }) {
  const { user, logout } = useAuth(); const nav = useNavigate()
  const admin = user?.role === 'ADMIN'
  return <div className="min-h-screen"><header className="border-b bg-white"><div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4">
    <Link to={admin ? '/admin' : '/analyst'} className="font-bold tracking-tight text-blue-700">◈ Data Quality Tracker</Link>
    <nav className="flex items-center gap-4 text-sm">
      {admin ? <><Link to="/admin">Dashboard</Link><Link to="/rulesets">Rule Sets</Link><Link to="/users">Users</Link><Link to="/uploads">All Uploads</Link></> : <><Link to="/analyst">Dashboard</Link><Link to="/upload">Validate File</Link><Link to="/uploads">My Uploads</Link></>}
      <span className="hidden text-slate-500 sm:inline">{user?.username} · {user?.role}</span>
      <button className="btn-secondary !px-3 !py-1.5" onClick={() => { logout(); nav('/') }}>Log out</button>
    </nav>
  </div></header><main className="mx-auto max-w-7xl px-5 py-8">{children}</main></div>
}
