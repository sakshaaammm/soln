import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom'
import './index.css'
import { AuthProvider, useAuth } from './context/AuthContext'
import ProtectedRoute from './components/ProtectedRoute'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import RuleSets from './pages/RuleSets'
import RuleSetForm from './pages/RuleSetForm'
import Users from './pages/Users'
import Upload from './pages/Upload'
import Uploads from './pages/Uploads'
import Results from './pages/Results'

function HomeRedirect(){const {user,loading}=useAuth();if(loading)return <div className="p-10 text-center">Loading…</div>;return <Navigate to={user?(user.role==='ADMIN'?'/admin':'/analyst'):'/'} replace/>}
function App(){return <AuthProvider><BrowserRouter><Routes>
<Route path="/" element={<Login/>}/>
<Route element={<ProtectedRoute roles={['ADMIN']}/>}>
<Route path="/admin" element={<Dashboard admin/>}/><Route path="/rulesets" element={<RuleSets/>}/><Route path="/rulesets/new" element={<RuleSetForm/>}/><Route path="/rulesets/:id/edit" element={<RuleSetForm/>}/><Route path="/users" element={<Users/>}/>
</Route>
<Route element={<ProtectedRoute roles={['DATA_ANALYST']}/>}>
<Route path="/analyst" element={<Dashboard/>}/><Route path="/upload" element={<Upload/>}/>
</Route>
<Route element={<ProtectedRoute roles={['ADMIN','DATA_ANALYST']}/>}>
<Route path="/uploads" element={<Uploads/>}/><Route path="/results/:id" element={<Results/>}/>
</Route>
<Route path="*" element={<HomeRedirect/>}/>
</Routes></BrowserRouter></AuthProvider>}
createRoot(document.getElementById('root')).render(<React.StrictMode><App/></React.StrictMode>)
