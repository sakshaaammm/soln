import { createContext, useContext, useEffect, useState } from 'react'
import api from '../api/client'
const AuthContext = createContext(null)
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  useEffect(() => {
    if (!localStorage.getItem('dqt_token')) { setLoading(false); return }
    api.get('/auth/me').then(r => setUser(r.data)).catch(() => setUser(null)).finally(() => setLoading(false))
  }, [])
  async function login(username, password) {
    const { data } = await api.post('/auth/login', { username, password })
    localStorage.setItem('dqt_token', data.access_token)
    localStorage.setItem('dqt_role', data.role)
    const me = await api.get('/auth/me')
    setUser(me.data)
    return me.data
  }
  function logout() { localStorage.removeItem('dqt_token'); localStorage.removeItem('dqt_role'); setUser(null) }
  return <AuthContext.Provider value={{ user, loading, login, logout }}>{children}</AuthContext.Provider>
}
export const useAuth = () => useContext(AuthContext)
