import axios from 'axios'
const api = axios.create({ baseURL: import.meta.env.VITE_API_URL || 'http://localhost:8000' })
api.interceptors.request.use(config => {
  const token = localStorage.getItem('dqt_token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})
api.interceptors.response.use(r => r, error => {
  if (error.response?.status === 401) {
    localStorage.removeItem('dqt_token')
    localStorage.removeItem('dqt_role')
    if (window.location.pathname !== '/') window.location.href = '/'
  }
  return Promise.reject(error)
})
export default api
