import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
export default function Login() {
 const [username,setUsername]=useState(''); const [password,setPassword]=useState(''); const [error,setError]=useState(''); const [busy,setBusy]=useState(false)
 const {login}=useAuth(); const nav=useNavigate()
 async function submit(e){e.preventDefault();setError('');setBusy(true);try{const u=await login(username,password);nav(u.role==='ADMIN'?'/admin':'/analyst')}catch(err){setError(err.response?.data?.detail||'Could not sign in. Check your credentials.')}finally{setBusy(false)}}
 return <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-950 via-slate-900 to-blue-950 px-4"><div className="grid w-full max-w-4xl overflow-hidden rounded-3xl bg-white shadow-2xl md:grid-cols-2">
  <div className="hidden flex-col justify-between bg-blue-700 p-10 text-white md:flex"><div className="text-sm font-bold uppercase tracking-[.2em]">DQ / CONTROL</div><div><h1 className="text-4xl font-bold leading-tight">Trust every dataset.</h1><p className="mt-4 text-blue-100">Validate files against consistent, transparent data quality rules.</p></div><p className="text-xs text-blue-200">Data quality, made actionable.</p></div>
  <form onSubmit={submit} className="p-8 sm:p-12"><p className="text-sm font-bold text-blue-700">DATA QUALITY FILE TRACKER</p><h2 className="mt-3 text-3xl font-bold">Welcome back</h2><p className="mt-2 text-slate-500">Sign in to continue to your workspace.</p>
  {error&&<div className="mt-5 rounded-lg bg-rose-50 p-3 text-sm text-rose-700">{error}</div>}
  <label className="mt-7 block text-sm font-semibold">Username or email</label><input className="mt-2" value={username} onChange={e=>setUsername(e.target.value)} autoComplete="username" required/>
  <label className="mt-5 block text-sm font-semibold">Password</label><input className="mt-2" type="password" value={password} onChange={e=>setPassword(e.target.value)} autoComplete="current-password" required/>
  <button className="btn mt-7 w-full" disabled={busy}>{busy?'Signing in…':'Sign in'}</button><p className="mt-5 text-xs text-slate-400">Access is restricted to authorized users.</p></form></div></div>
}
