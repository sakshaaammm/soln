import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import api from '../api/client'
import Layout from '../components/Layout'
import StatusBadge from '../components/StatusBadge'
export default function Uploads(){
 const [items,setItems]=useState([]),[error,setError]=useState('')
 useEffect(()=>{api.get('/uploads').then(r=>setItems(r.data)).catch(e=>setError(e.response?.data?.detail||'Could not load uploads'))},[])
 async function download(id){try{const r=await api.get(`/uploads/${id}/download`,{responseType:'blob'});const url=URL.createObjectURL(r.data);const a=document.createElement('a');a.href=url;a.download=`flagged_report_${id}.xlsx`;a.click();URL.revokeObjectURL(url)}catch{setError('Could not download report.')}}
 return <Layout><h1 className="text-3xl font-bold">Upload history</h1><p className="mt-2 text-slate-500">Review validation results and download flagged reports.</p>{error&&<p className="mt-4 rounded bg-rose-50 p-3 text-rose-700">{error}</p>}
 <div className="card mt-6 overflow-x-auto"><table className="w-full text-left text-sm"><thead className="border-b text-xs uppercase text-slate-500"><tr>{['File','Rule set','Uploaded','Rows','Issues','Status','Actions'].map(x=><th className="py-3 pr-4" key={x}>{x}</th>)}</tr></thead><tbody>{items.map(x=><tr key={x.id} className="border-b last:border-0"><td className="py-4 pr-4 font-semibold">{x.file_name}</td><td className="pr-4">{x.ruleset_name}</td><td className="pr-4">{x.created_at?new Date(x.created_at).toLocaleString():'—'}</td><td className="pr-4">{x.total_rows}</td><td className="pr-4">{x.issue_count}</td><td className="pr-4"><StatusBadge status={x.status}/></td><td className="flex gap-3 py-4"><Link className="font-semibold text-blue-700" to={`/results/${x.id}`}>View</Link>{x.status==='FLAGGED'&&<button className="font-semibold text-blue-700" onClick={()=>download(x.id)}>Download</button>}</td></tr>)}{!items.length&&<tr><td colSpan="7" className="py-10 text-center text-slate-500">No uploads yet.</td></tr>}</tbody></table></div></Layout>
}
