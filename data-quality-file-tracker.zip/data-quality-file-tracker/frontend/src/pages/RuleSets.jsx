import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import api from '../api/client'
import Layout from '../components/Layout'
import { useAuth } from '../context/AuthContext'
export default function RuleSets(){
 const [items,setItems]=useState([]),[err,setErr]=useState('');const {user}=useAuth()
 const load=()=>api.get('/rulesets').then(r=>setItems(r.data)).catch(e=>setErr(e.response?.data?.detail||'Could not load rule sets'))
 useEffect(()=>{load()},[])
 async function toggle(r){try{await api.put(`/rulesets/${r.id}`,{...r,is_active:!r.is_active});load()}catch(e){setErr(e.response?.data?.detail||'Update failed')}}
 async function remove(r){if(!confirm(`Delete/deactivate "${r.name}"?`))return;try{await api.delete(`/rulesets/${r.id}`);load()}catch(e){setErr(e.response?.data?.detail||'Delete failed')}}
 return <Layout><div className="flex items-center justify-between gap-4"><div><h1 className="text-3xl font-bold">Validation rule sets</h1><p className="mt-2 text-slate-500">Define the standards each dataset must meet.</p></div>{user.role==='ADMIN'&&<Link className="btn" to="/rulesets/new">+ Create rule set</Link>}</div>
 {err&&<p className="mt-4 rounded-lg bg-rose-50 p-3 text-rose-700">{err}</p>}
 <div className="mt-6 grid gap-4 md:grid-cols-2">{items.map(r=><article className="card" key={r.id}><div className="flex items-start justify-between gap-3"><div><h2 className="text-lg font-bold">{r.name}</h2><p className="mt-1 text-sm text-slate-500">{r.description||'No description.'}</p></div><span className={`rounded-full px-2 py-1 text-xs font-bold ${r.is_active?'bg-emerald-100 text-emerald-700':'bg-slate-100 text-slate-500'}`}>{r.is_active?'ACTIVE':'INACTIVE'}</span></div>
 <div className="mt-4 flex flex-wrap gap-2 text-xs"><span className="rounded bg-slate-100 px-2 py-1">{(r.rules.mandatory_columns||[]).length} mandatory columns</span><span className="rounded bg-slate-100 px-2 py-1">{Object.keys(r.rules.columns||{}).length} configured columns</span><span className="rounded bg-slate-100 px-2 py-1">{(r.rules.allowed_file_types||['.csv','.xlsx']).join(', ')}</span></div>
 <div className="mt-5 flex gap-2">{user.role==='ADMIN'?<><Link className="btn-secondary text-sm" to={`/rulesets/${r.id}/edit`}>Edit</Link><button className="btn-secondary text-sm" onClick={()=>toggle(r)}>{r.is_active?'Deactivate':'Activate'}</button><button className="btn-secondary text-sm text-rose-700" onClick={()=>remove(r)}>Delete</button></>:<Link className="btn-secondary text-sm" to={`/upload?ruleset=${r.id}`}>Use this rule set</Link>}</div></article>)}</div>
 {!items.length&&<div className="card mt-6 text-center text-slate-500">No rule sets found.</div>}</Layout>
}
