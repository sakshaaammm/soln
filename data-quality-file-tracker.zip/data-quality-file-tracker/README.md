# Data Quality File Tracker

A full-stack starter application for validating CSV and Excel datasets against admin-managed rule sets.

## Features
- JWT login, bcrypt password hashing, first-run admin seeding from `.env`
- Backend role guards for admin and analyst endpoints
- Admin rule-set management, analyst user management, and all-upload monitoring
- Analyst uploads, validation results, upload history, and flagged workbook download
- Modular pandas validation engine and generated XLSX reports with highlighted cells, comments, Issue Summary, and Checks sheets
- SQLite by default, SQLAlchemy URL configurable for PostgreSQL
- React/Vite, React Router, Axios auth interceptor, Tailwind CSS

## Run locally

### 1. Backend
```bash
cd backend
python -m venv .venv
# Windows PowerShell: .venv\Scripts\Activate.ps1
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
# Copy .env.example to .env, then change SECRET_KEY and DEFAULT_ADMIN_PASSWORD
# Windows: copy .env.example .env
# macOS/Linux: cp .env.example .env
uvicorn app.main:app --reload
```
API docs: http://localhost:8000/docs

Default local admin values from `.env.example`:
- Username: `admin`
- Email: `admin@example.com`
- Password: `ChangeMe123!`

Change these before exposing the application beyond localhost. The admin is seeded only if no admin exists in the database.

### 2. Frontend
Open another terminal:
```bash
cd frontend
npm install
npm run dev
```
Open http://localhost:5173. Optional: create `frontend/.env` with `VITE_API_URL=http://localhost:8000`.

### 3. Create the sample benchmark
Sign in as admin, open Rule Sets → Create rule set, and use `sample-data/sample-ruleset.json` as a reference for the rules. The app currently has no automatic JSON-import button. Add the benchmark fields through the UI or POST the following shape to `/rulesets` with an admin bearer token:
```json
{
  "name": "Customer Import Benchmark",
  "description": "Example benchmark for customer imports.",
  "is_active": true,
  "rules": {
    "column_matching": "case_insensitive",
    "mandatory_columns": ["customer_id", "email", "status", "amount"],
    "allowed_file_types": [".csv", ".xlsx"],
    "max_file_size_mb": 20,
    "min_rows": 1,
    "columns": {
      "customer_id": {"not_null": true, "unique": true, "type": "string", "min_length": 4},
      "email": {"not_null": true, "type": "string", "regex": "^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$"},
      "status": {"not_null": true, "allowed_values": ["active", "pending", "closed"]},
      "amount": {"type": "float", "min": 0, "max": 100000}
    }
  }
}
```
Upload `sample-data/sample-pass.csv` to get PASS and `sample-data/sample.csv` to get FLAGGED.

## API overview
- `POST /auth/login`, `GET /auth/me`
- `POST /users`, `GET /users`, `PATCH /users/{id}/active?active=true|false` (admin)
- `GET /rulesets` (analysts see active only), `POST /rulesets`, `GET /rulesets/{id}`, `PUT /rulesets/{id}`, `DELETE /rulesets/{id}`
- `POST /uploads` (multipart fields: `file`, `ruleset_id`)
- `GET /uploads`, `GET /uploads/{id}`, `GET /uploads/{id}/download`

## Rule JSON shape
```json
{
  "column_matching": "exact | case_insensitive | ignore_spaces",
  "mandatory_columns": ["customer_id", "email"],
  "disallow_extra_columns": false,
  "allowed_file_types": [".csv", ".xlsx"],
  "max_file_size_mb": 20,
  "min_rows": 1,
  "max_rows": 50000,
  "columns": {
    "email": {
      "not_null": true,
      "type": "string",
      "regex": "^[^@]+@[^@]+\\.[^@]+$",
      "unique": true,
      "allowed_values": ["..."],
      "min": 0,
      "max": 100,
      "min_length": 3,
      "max_length": 255,
      "date_format": "%Y-%m-%d"
    }
  }
}
```

## Notes / production hardening
- Legacy `.xls` parsing uses `xlrd`; `.xlsx` parsing uses `openpyxl`.
- Add rate limiting, audit logging, password reset/rotation, CSRF considerations if switching to cookies, malware scanning, storage retention policies, and production HTTPS before deployment.
- This is a starter implementation; validate rule configurations and run automated tests before production use.
